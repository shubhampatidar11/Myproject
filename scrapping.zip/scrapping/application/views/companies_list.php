<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Companies List</title>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">

</head>
<body>
<div class="page-header">
	<h2 align="center">Indore Companies List</h2>
</div>
<div class="container">
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Email</th>
                <th>Phone No</th>
                <th>Mobile No</th>
            </tr>
        </thead>
        <tbody>
        	<?php
        	foreach($sql as $row)
        	{
        		echo "<tr>";
        		echo "<td>".$row->company_name."</td>";
        		echo "<td>".$row->address."</td>";
        		echo "<td>".$row->email."</td>";
        		echo "<td>".$row->phone_no."</td>";
        		echo "<td>".$row->mobile_no."</td>";
        		echo "</tr>";
        	}
        	?>
        </tbody>
        <tfoot>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Email</th>
                <th>Phone No</th>
                <th>Mobile No</th>
            </tr>
        </tfoot>
</table>
</div>
</body>
</html>
<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>