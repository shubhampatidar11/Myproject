<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
		$this->load->helper('cookie');
		$this->load->helper('form');

		$this->load->database();
		
	}

	public function index()
	{
		if(isset($_POST['click']))
		{

		echo "<pre>";
		print_r($_POST);
		die();
		}
		$data['sql']=$this->db->query("SELECT * FROM amenities");
		$this->load->view('first',$data);
	}
}
