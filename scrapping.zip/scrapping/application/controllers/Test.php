<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

	// public function __construct()
	// {
	// 	parent::__construct();
		
	// 	$this->load->helper('url');
	// 	$this->load->helper('cookie');
	// 	$this->load->helper('form');

	// 	$this->load->database();
		
	// }

	function testing_test()
	{
		// echo $id;
		// echo 'hello';
		// $c=$a+$b;

		// echo $c;
		// echo '$E';

		$car=array(3,2,4,23,1,5,6,7,33);

		$count=count($car);
		// $max=$car[0];
		// $te=array();
		// for($i=0;$i<$count;$i++)
		// {
		// 	if($max<$car[$i])
		// 	{
		// 		$max=$car[$i];
		// 		$te[]=$car[$i];

		// 	}
			
		// }
		// print_r($te);
		// $this->terms();
		for($i=0;$i<$count;$i++)
		{
			for($j=0;$j<$count;$j++)
			{
				if($car[$j]>$car[$i])
				{
					$temp=$car[$i];
					$car[$i]=$car[$j];
					$car[$j]=$temp;
				}
			}
		}
		// echo $car;
		print_r($car);	
		echo "<br/>";
		for($i=0;$i<$count;$i++)
		{
			for($j=0;$j<$count;$j++)
			{
				if($car[$i]>$car[$j])
				{
					$temp=$car[$i];
					$car[$i]=$car[$j];
					$car[$j]=$temp;
				}
			}
		}
		// echo $car;
		print_r($car);	
	}




	// public function _remap($method)
	// {
 //        if ($method == '2.0')
 //        {
 //                $this->testing_test();
 //        }
 //        else
 //        {
 //                echo 'test2';
 //        }
	// }
}
?>