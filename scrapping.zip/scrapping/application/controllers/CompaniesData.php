<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CompaniesData extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
		$this->load->helper('cookie');
		$this->load->helper('form');

		$this->load->database();
		
	}
	public function index()
	{
		$data['sql']=$this->db->query("select * from company_details")->result();
		// echo $this->db->last_query();die;
		$this->load->view('companies_list',$data);
	}
}
