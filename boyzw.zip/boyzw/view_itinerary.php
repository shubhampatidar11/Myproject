<?php
ini_set('session.gc_maxlifetime', 10800);
ini_set('max_execution_time', 1600);
ini_set('memory_limit','-1');

$page['title'] = 'Create an itinerary';
include('template/generic/header.php');
include('template/generic/navigation.php'); 
$get_id=$_GET['id'];

// for get source from url

				$source ='';
				$source_url_param ='';
				if(isset($_GET['source']))
				{ 
					$source = $_GET['source'];
					$source_url_param = "&source=$source";

				}
				
// for get source from url endd

if(isset($get_id))
{


$query_for_fetch="SELECT * FROM `itinerary` WHERE id=".$get_id;
$result_for_fetch=mysql_query($query_for_fetch);
$data_from_copy=mysql_fetch_assoc($result_for_fetch);
}
?>
<div class="admin-submenu buttons">
  <a href="../admin/?section=itinerary&act=view">Back to list</a>
  <div style="clear: both;"></div>
</div>
<h1 align="center" style="color: black;font-size: 36px;">Create an Itinerary</h1>

<?php
// Success Message handler -> import into utility class
if($_SESSION['success_message'] != '')
{
	echo '<p class="gt-success">'.$_SESSION['success_message'].'</p>';
	unset($_SESSION['success_message']);
}
?>
<link href="boyz_026.ico" rel="shortcut icon" type="image/x-icon" />    
<script src="../js/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript">
$(document).ready(function(){
		var date2=document.getElementById("from_date").value;
		var date1=document.getElementById("to_date").value;

			if(date2!='' && date1!='')
				{
				$("#show_gtotal_div").show();
				}else
				{
				$("#show_gtotal_div").hide();

				}

});
</script>
<script type="text/javascript">
	
function fill_product(pid1,pid2,first_id)
{

			// alert('test'+pid1+" 111 "+pid2+" 222 "+first_id);

	$.ajax({

             url:'index.php?section=itinerary&act=fill_products',
             success: function(result)
              {

		 	    var product_id="product_"+pid1+"_"+pid2;
	           	document.getElementById(product_id).innerHTML = result;
              }
           });
}

</script>
<script>
function productPrice(pid1,pid2,first_id){
	// alert(pid1);alert(pid2);
	// alert(first_id);
	 	var product_id="product_"+pid1+"_"+pid2;
	 var product_by_id="&product_by_id="+document.getElementById(product_id).value;
	 var number_of_persons=document.getElementById("number_of_persons").value;
	
	var no_of_person_row="calculate_row_"+pid1+"_"+pid2;
	var no_of_person_row_data=document.getElementById(no_of_person_row).value;
	// alert(no_of_person_row_data);
	var source=document.getElementById("source").value;
	var data_send = 'product_by_id='+ product_by_id  & 'source='+ source;
	//alert(product_by_id);
	// alert('index.php?section=itinerary&act=get_price<?php echo $source_url_param; ?>');
		  $.ajax({
            type:'GET', 	
            url:'index.php?section=itinerary&act=get_price<?php echo $source_url_param; ?>',
            data: product_by_id,
                
            success: function(result){
            	// alert(result);
            	var str_split_price = result.split("#");
            	var response=str_split_price[0];
            	var supplier_price_from_ajax=str_split_price[1];
            	
            	// alert(response);
            	// alert(supplier_price_from_ajax);
            	if($.isNumeric(supplier_price_from_ajax))
            	  {
            		document.getElementById("supplier_price_"+pid1+"_"+pid2).value=supplier_price_from_ajax; 
            	  }else
            	  {
            	  	supplier_price_from_ajax='0';
            	  	document.getElementById("supplier_price_"+pid1+"_"+pid2).value=supplier_price_from_ajax;	
            	  }
            	

            	 if($.isNumeric(response))
            	  {
                             document.getElementById("price_"+pid1+"_"+pid2).value=response; 
                             document.getElementById("total_price_"+pid1+"_"+pid2).value=response*number_of_persons;
                             if(no_of_person_row_data!='')
                             {
                             document.getElementById("total_price_"+pid1+"_"+pid2).value=response*no_of_person_row_data;	
                             }
                             // alert(response);
							// setTimeout(function () {
							// 	alert('test');
							
							// }, 1000);

                             subtotal_datevise();
                             grandtotal_datewise();
                             subtotal_datevise_for_multi_dates(first_id);
                             subtotal_datevise_supplier();
			 				grandtotal_datewise_supplier();
			 				subtotal_datevise_for_multi_dates_supplier(first_id);
                             // $("#price").html(response);
           		   }else
           		   {
           		   	response='0';
           		   	document.getElementById("price_"+pid1+"_"+pid2).value=response; 
                             document.getElementById("total_price_"+pid1+"_"+pid2).value=response*number_of_persons;
                             if(no_of_person_row_data!='')
                             {
                             document.getElementById("total_price_"+pid1+"_"+pid2).value=response*no_of_person_row_data;	
                             }
                             
                             subtotal_datevise();
                             grandtotal_datewise();
                             subtotal_datevise_for_multi_dates(first_id);
                             subtotal_datevise_supplier();
			 				grandtotal_datewise_supplier();
			 				subtotal_datevise_for_multi_dates_supplier(first_id);
                             // $("#price").html(response);

           		   }
            }
        });

	}
			 function newTotal_price(pid1,pid2,first_id){
			 	
			 	var price="price_"+pid1+"_"+pid2;
				var price_data=document.getElementById(price).value;
			 	var number_of_persons=document.getElementById("number_of_persons").value;

			 	var no_of_person_row="calculate_row_"+pid1+"_"+pid2;
	var no_of_person_row_data=document.getElementById(no_of_person_row).value;

	if(no_of_person_row_data!='')
	{
		document.getElementById("total_price_"+pid1+"_"+pid2).value=price_data*no_of_person_row_data;
	}else
	{
		document.getElementById("total_price_"+pid1+"_"+pid2).value=price_data*number_of_persons;
	}
			 	
                             subtotal_datevise();
			 				grandtotal_datewise();
			 				subtotal_datevise_for_multi_dates(first_id);
			 }

			 function newsupplier(pid1,pid2,first_id)
			 {
			 	            subtotal_datevise_supplier();
			 				grandtotal_datewise_supplier();
			 				subtotal_datevise_for_multi_dates_supplier(first_id);
			 }
function numbers_total(pid1,pid2,first_id)
{
	var number_of_persons=document.getElementById("number_of_persons").value;

	var price="price_"+pid1+"_"+pid2;
	var price_data=document.getElementById(price).value;
	// alert(price_data);

	var no_of_person_row="calculate_row_"+pid1+"_"+pid2;
	var no_of_person_row_data=document.getElementById(no_of_person_row).value;
	
	if(isNaN(no_of_person_row_data) || no_of_person_row_data==0 )
	{
		// alert('Please insert number only');
		document.getElementById(no_of_person_row).value='';
	}

	if($.isNumeric(no_of_person_row_data)=='')
	{
		if(number_of_persons!='')
     	{

     		no_of_person_row_data=number_of_persons;
     	}else{
     		no_of_person_row_data=0;	
     	}

		document.getElementById("total_price_"+pid1+"_"+pid2).value=price_data*parseInt(no_of_person_row_data);
	 
	 	subtotal_datevise();
	 	grandtotal_datewise();
	 	subtotal_datevise_for_multi_dates(first_id);
	}else
	{
     document.getElementById("total_price_"+pid1+"_"+pid2).value=price_data*parseInt(no_of_person_row_data);
	 
	 		subtotal_datevise();
		    grandtotal_datewise();
	 	    subtotal_datevise_for_multi_dates(first_id);

	 }
	
}

	function checkNAN(){
		//alert();
		$(".row_total").val(''); //for null all numbers 
		var number1=document.getElementById("number_of_persons").value;
		//commented
			// if(number1<1){
			// 	document.getElementById("Error_num").innerHTML="Please check your number";
			// }else{
			// 	document.getElementById("Error_num").innerHTML="";
		//commented

			// $('.product_list').each(function(){
				
				
   //     		 // 	var value = $('input[id^="txtAnswer"]').val();
	  //       	// var id = $('input[id^="txtAnswer"]').attr('id');
	  //       	// alert('id: ' + id + ' value:' + value);
	  //       });
			var price1=[] ;
			var idr=[];
	        $('.price_class').each(function(){
		       		 	//var value = $(this).val();
		       		var value = $(this).val();
						price1.push(value);
	       		 });
	        $('.total_price_class').each(function(){
		       		 	//var value = $(this).val();
		       		var total_price_id = $(this).attr('id');
						idr.push(total_price_id);
	       		 });
	        allfield_changed=0;
	        for(var i=0;i<price1.length;i++)
	        {
	        	var price_val = price1[i];
	        	var total_price_idr = idr[i];
	        	$('#'+total_price_idr).val(price_val*number1);
	        	 allfield_changed=1;
	        }
	         if(allfield_changed==1){

			         $('.TextBoxDiv_class').each(function(){
				       		 	//var value = $(this).val();
				       		var TextBoxDiv_id = $(this).attr('id');
				       		// alert(TextBoxDiv_id);
				       		var table_ids = TextBoxDiv_id.split("v",2);
								 
								
								first_id = table_ids['1'];
								// alert(first_id);
							
								subtotal_datevise_for_multi_dates(first_id);
			       		 });
				}

                             subtotal_datevise();
                             grandtotal_datewise();
                             


		// }else endss commented
	}

function subtotal_datevise_for_multi_dates(first_id)
{
	 // alert(first_id);
	//alert(first_id);alert(second_id);alert(third_id);
	var total_for_price=0;
	$( "#TextBoxDiv"+first_id).find(".total_price_class").each(function() {
  		var sum_for_price=$( this ).val();
  		
  		if(sum_for_price!=''){
  			total_for_price=parseFloat(total_for_price)+parseFloat(sum_for_price);
			}
	});
	
	// $( "#sum_total").val(total_for_price);
	$( "#total_div_"+first_id).find(".sum_total").val(total_for_price);
	

	// alert("first_id "+first_id);
	var total_for_rate=0;
	$( "#TextBoxDiv"+first_id).find(".price_class").each(function() {
  		var sum_for_rate=$( this ).val();
  		if(sum_for_rate!=''){
  			total_for_rate=parseFloat(total_for_rate)+parseFloat(sum_for_rate);
  	    	}
	});
	// $( "#price_total").val(total_for_rate);
	// alert(total_for_rate);
	$( "#total_div_"+first_id).find(".price_total").val(total_for_rate);

	

}
function subtotal_datevise_for_multi_dates_supplier(first_id)
{
	var total_for_supplier=0;
	$( "#TextBoxDiv"+first_id).find(".supplier_price_class").each(function() {
  		var sum_for_supplier=$( this ).val();
  		if(sum_for_supplier!=''){
  			total_for_supplier=parseFloat(total_for_supplier)+parseFloat(sum_for_supplier);
  	    	}
	});
	// $( "#price_total").val(total_for_rate);
	$( "#total_div_"+first_id).find(".supplier_price_total").val(total_for_supplier);
	}
function grandtotal_datewise(){
			var total_for_price=0;
			$(".total_price_class").each(function() {
 			var sum_for_price=$( this ).val();
 				if(sum_for_price!=''){ 
  					total_for_price=parseFloat(total_for_price)+parseFloat(sum_for_price);
		  			}
				});
			$( ".grandtotal").val(total_for_price);

			var total_for_rate=0;
			$(".price_class").each(function() {
  			var sum_for_rate=$( this ).val();
  				if(sum_for_rate!=''){
  					total_for_rate=parseFloat(total_for_rate)+parseFloat(sum_for_rate);
				}
			});
			$( ".grandpricetotal").val(total_for_rate);

			
   
}
function grandtotal_datewise_supplier(){
	var total_for_supplier=0;
			$(".supplier_price_class").each(function() {
  			var sum_for_supplier=$( this ).val();
  				if(sum_for_supplier!=''){
  					total_for_supplier=parseFloat(total_for_supplier)+parseFloat(sum_for_supplier);
				}
			});
			$( ".grandsuppliertotal").val(total_for_supplier);
}
function check_uncheck_price(first_id)
{
	// alert()id="check_price_hidden_'+counter+'"
	if(document.getElementById("check_price_"+first_id).checked)
	{
	document.getElementById("check_price_hidden_"+first_id).value=1;
	}else
	{
	document.getElementById("check_price_hidden_"+first_id).value=0;

	}

}

// function grandtotal_pricewise(){
			
   
// }
	function days_between()
	{

		var date2=document.getElementById("from_date").value;
		var date1=document.getElementById("to_date").value;
		if(date1=='')
		{
			 date1=date2;
		}
		
		// alert(date1);
		if(date2!='' && date1!='')
{
	$("#show_gtotal_div").show();
}else
{
	$("#show_gtotal_div").hide();

}
		// alert(date2);alert(date1);
		$("#TextBoxesGroup").html("");
		if(date1=='')
		{
 			date1=date2;
		}
			
		var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
		var firstDate = new Date(date1);
		var secondDate = new Date(date2); 
		var tomorrow =secondDate; 
		var newdate = secondDate;
		//alert(newdate);
		var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
		// alert(diffDays);


		$(function() 
		{
			var counter=1;
			if(diffDays == 0){
				var year = newdate.getFullYear();
				var month = newdate.getMonth()+1;
				var day =  newdate.getDate();
				var on_date_concate = year +"-"+month+"-"+day;
				var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				//var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

				var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
				show_date = days[newdate.getDay()]+' '+day+' '+ months[newdate.getMonth()];
				//alert(show_date);
				var newDateShowDiv = $(document.createElement('div')).attr("id", 'DateShowDiv' + 0).attr("style", 'margin-top: 15px;');
				newDateShowDiv.after().html(show_date);
				newDateShowDiv.appendTo("#TextBoxesGroup");
	
				var newTextBoxDiv = $(document.createElement('table')).attr("id", 'TextBoxDiv' + 0).attr("style", 'padding:15px;width:130%;border: 1px solid #ddd;margin-bottom: 15px;');
				 
				var after_div ="'"+"row_box_00"+"'";
				// alert(on_date);
				newTextBoxDiv.after().html(
					'<div style="float:left;margin-top: -20px; "><span style="border: 1px solid darkgray;padding: 3px;background-color: #E7E7E7;">Numbers</span></div><div style="float:right;margin-top: -23px; "><a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child('+0+', '+year +','+month+','+day+',0,'+after_div+');" > + Add Product </a>	</div><div style="margin-bottom: 10px;float: left;" id="row_box_0'+0+'"><div  style="float: left;width: 7%; "><input id="calculate_row_0_' + 0 + '" class="row_total" onkeyup="numbers_total('+0+','+0+','+0+')" name="numbers[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:75%;"  value=""></div><div class="" style="float: left;width: 30%;padding-right: 4px "><div class="select select-block ">'
					+'<?php if($source=='boyzweekend'){ ?><?php $product_data = "SELECT * FROM products WHERE source='$source'   ORDER BY title ASC  "; $product_result = mysql_query($product_data);?>'
					+'<select id="product_0_' + 0 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+0+','+0+')">'
					+'<option value= "">Select Product</option>'
					+'<?php while($product_info = mysql_fetch_array($product_result)){ ?>'
					+'<option value= "<?php echo $product_info[id];?>">'
					+"<?php echo $product_info[title]; ?>"
					+'</option>'
					+'<?php } ?> '
					+'</select><?php }else{?>'
					+'<select id="product_0_' + 0 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+0+','+0+')"  >'
					+'</select><?php } ?>'
					+'</div></div>'
					+'<div class="select select-block " style="float: left;width: 7%; 	padding-right: 10px;"><select id="from_time_0_' + 0 + '" class="from_time" name="from_time[]"style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time From</option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
					+'<div class="select select-block " style="float: left;width: 7%; 	padding-right: 10px;"><select id="to_time_0_' + 0 + '" class="to_time" name="to_time[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time To</option>'
					+'<option value="17:17:17"></option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'

					+'<div class="" style="float: left;width: 7%;	padding-right: 10px; "><input id="price_0_' + 0 + '" name="price[]"  onchange="newTotal_price('+0+','+0+')" placeholder="Price" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="price_class"></div>'
					+'<div class="" style="float: left;width: 7%;	padding-right: 10px; "><input id="supplier_price_0_' + 0 + '" name="supplier_price[]"   placeholder="Supplier Price" onchange="newsupplier('+0+','+0+')" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="supplier_price_class"></div>'
					+'<div class="" style="float: left;width: 7%;	padding-right: 10px;"><input id="total_price_0_' + 0 + '" readonly name="total_price[]" class="total_price_class" placeholder="Total Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"><input type="hidden" id="on_date' + 0 + '" name="on_date[]" value="'+on_date_concate+'"> </div>'
					+'<div class="" style="float: left;width: 18%;	padding-right: 10px; "><textarea id="itinerary_package_additional_instructions_0_' + 0 + '" name="itinerary_package_additional_instructions[]"   placeholder="Additional Instructions here..." style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="itinerary_package_additional_instructions_class"></textarea></div>'
			
					+'<div class="" style="float: left;width: 2%;	padding-right: 10px;"><input type="checkbox" id="check_price_' + counter + '" name="check_price1" onclick="check_uncheck_price('+counter+');"  style="height: 15px;width: 15px;margin-top: 6px;margin-left:13px;"><input type="hidden" name="check_price[]" id="check_price_hidden_'+counter+'" value="0"></div>'
					+'</div>'
					+'<div id="total_div_0"><div  style="margin-left:531px;float: left;margin-top: 4px;"><strong>Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  id="price_total" class="price_total" name="price_total" style="width:78px;padding-left: 1px;padding:2px;" disabled>&nbsp;<input type="text"  id="supplier_price_total" class="supplier_price_total" name="supplier_price_total" style="width:78px;padding-left: 1px;padding:2px;" disabled>&nbsp;<input type="text" id="sum_total" class="sum_total" name="total" style="width:78px;padding-left: 1px;padding:2px;"  disabled></div></div>'

					);
		
				newTextBoxDiv.appendTo("#TextBoxesGroup");
				newdate.setDate(tomorrow.getDate() + 1);
				<?php 
					if($source=='girlzweekend'){?>
					
						fill_product('0','0');
					<? }?>
		
			}else{
				// show_hide_grandtotal_div();
			first_id=1;
			for(counter=1; counter<=diffDays; counter++) 
			{
				
				var year = newdate.getFullYear();
				var month = newdate.getMonth()+1;
				var day =  newdate.getDate();
				var on_date_concate = year +"-"+month+"-"+day;
				var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				//var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

				var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
				show_date = days[newdate.getDay()]+' '+day+' '+ months[newdate.getMonth()];
				//alert(show_date);
				var newDateShowDiv = $(document.createElement('div')).attr("id", 'DateShowDiv' + counter).attr("style", 'margin-top: 15px;');
				newDateShowDiv.after().html(show_date);
				newDateShowDiv.appendTo("#TextBoxesGroup");
			
				var newTextBoxDiv = $(document.createElement('table')).attr("id", 'TextBoxDiv' + counter).attr("style", 'padding:15px;width:130%;border: 1px solid #ddd;margin-bottom: 15px;').attr("class", 'TextBoxDiv_class');
				var after_div ="'"+"row_box_0"+counter+"'";
				// alert(on_date);
				newTextBoxDiv.after().html(
					'<div style="float:left;margin-top: -20px; "><span style="border: 1px solid darkgray;padding: 3px;background-color: #E7E7E7;">Numbers</span></div><div style="float:right;margin-top: -23px; "><a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child('+counter+', '+year +','+month+','+day+','+first_id+','+after_div+');" > + Add Product </a>	</div><div style="margin-bottom: 10px;float: left;" id="row_box_0'+counter+'"><div class="" style="float: left;width: 7%; "><input name="numbers[]" id="calculate_row_0_' + counter + '" style="padding:2px;border-radius: 0px;margin-top: 3px;width:75%;"  class="row_total" onkeyup="numbers_total('+0+','+counter+','+first_id+')" value=""></div><div class="" style="float: left;width: 30%;padding-right: 4px "><div class="select select-block ">'
					+'<?php if($source=='boyzweekend'){?><?php $product_data = "SELECT * FROM products WHERE source='$source' ORDER BY title ASC  "; $product_result = mysql_query($product_data);?>'
					+'<select id="product_0_' + counter + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+0+','+counter+','+first_id+')">'
					+'<option value= "">Select Product</option>'
					+'<?php while($product_info = mysql_fetch_array($product_result)){ ?>'
					+'<option value= "<?php echo $product_info[id];?>">'
					+"<?php echo $product_info[title]; ?>"
					+'</option>'
					+'<?php } ?> '
					+'</select><?php }else{?>'
					+'<select id="product_0_' + counter + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+0+','+counter+','+first_id+')" > '
					+'</select><?php } ?>'
					+'</div></div>'
					+'<div class="select select-block " style="float: left;width: 7%; 	padding-right: 10px;"><select id="from_time_0_' + counter + '" class="from_time" name="from_time[]"style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time From</option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
					+'<div class="select select-block " style="float: left;width: 7%; 	padding-right: 10px;"><select id="to_time_0_' + counter + '" class="to_time" name="to_time[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time To</option>'
					+'<option value="17:17:17"></option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
					
					+'<div class="" style="float: left;width: 7%;	padding-right: 10px; "><input id="price_0_' + counter + '" name="price[]"  onchange="newTotal_price('+0+','+counter+','+first_id+')" placeholder="Price" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="price_class"></div>'
					+'<div class="" style="float: left;width: 7%;	padding-right: 10px; "><input id="supplier_price_0_' + counter + '" name="supplier_price[]"  placeholder="Supplier Price" onchange="newsupplier('+0+','+counter+','+first_id+')" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="supplier_price_class"></div>'
					+'<div class="" style="float: left;width: 7%;	padding-right: 10px;"><input id="total_price_0_' + counter + '" readonly name="total_price[]" class="total_price_class" placeholder="Total Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"><input type="hidden" id="on_date' + counter + '" name="on_date[]" value="'+on_date_concate+'"> </div>'
					+'<div class="" style="float: left;width: 18%;	padding-right: 10px; "><textarea id="itinerary_package_additional_instructions_0_' + counter + '" name="itinerary_package_additional_instructions[]"   placeholder="Additional Instructions here..." style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="itinerary_package_additional_instructions_class"></textarea></div>'
									
					+'<div class="" style="float: left;width: 2%;	padding-right: 10px;"><input type="checkbox" id="check_price_' + counter + '" name="check_price1" onclick="check_uncheck_price('+counter+');"  style="height: 15px;width: 15px;margin-top: 6px;margin-left:13px;"><input type="hidden" name="check_price[]" id="check_price_hidden_'+counter+'" value="0"></div>'
					
					+'</div>'
					+'<div id="total_div_'+counter+'"><div  style="margin-left:531px;float: left;margin-top: 4px;"><strong>Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  id="price_total" class="price_total" name="price_total" style="width:78px;padding-left: 1px;padding:2px;" disabled>&nbsp;<input type="text"  id="supplier_price_total" class="supplier_price_total" name="supplier_price_total" style="width:78px;padding-left: 1px;padding:2px;" disabled>&nbsp;<input type="text" id="sum_total" class="sum_total" name="total" style="width:78px;padding-left: 1px;padding:2px;margin-left: -2px;"  disabled></div></div>'

					);
				<?php 
				if($source=='girlzweekend'){?>
				
					fill_product('0',counter,first_id);
				<?php }?>
				newTextBoxDiv.appendTo("#TextBoxesGroup");
				newdate.setDate(tomorrow.getDate() + 1);
				first_id++;

			} 


			if(!date1)
			{
				//alert("Please Enter To Date");
			}
			else if(!date2)
			{
				//alert("Please Enter From Date");
			}
			else
			{
				var year1 = firstDate.getFullYear();
				var month1 = firstDate.getMonth()+1;
				var day1 =  firstDate.getDate();
			  
				var days1 = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				//var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

				var months1 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
				show_date1 = days1[newdate.getDay()]+' '+day1+' '+ months1[newdate.getMonth()];


				var newDateShow = $(document.createElement('div')).attr("id", 'DateShow').attr("style", 'margin-top: 15px;');
				newDateShow.after().html(show_date1);
				newDateShow.appendTo("#TextBoxesGroup");
				var LastDiv = $(document.createElement('div')).attr("id", 'LastDiv').attr("style", '');
				
				LastDiv.after().html('<div style="width:130%;border: 1px solid #ddd;margin-bottom: 15px;"><div style="border: 1px solid #ddd;"><table style="width: 100%;"><tr><td style="width: 50%;border-right: 1px #cac6c6 solid;height: 20px;">10 am</td><td style="text-align: center;">Check Out - Free Day</td></tr><tr><td colspan="2" style="width: 50%;height: 20px;"><textarea name="check_out_content" id="additional_content" style="width: 99%;height: 65px;" placeholder="Additional Content Here....."></textarea></td></tr></table></div></div>');
				LastDiv.appendTo("#TextBoxesGroup");
				}
				}
			});
	
		    
    
		
	
	}
</script>
<script type="text/javascript">
	var counter1=2;
	var first_id=1;
	var counter=1;
	// ***************************commented old 28****************************
	
	// ***************************commented old 28****************************
	// for new child add more product append
		var counter1_new=2;

	function newProduct_child(i,year,month,day,first_id,after_div)
	{
		on_date = year +'-'+month+'-'+day;

     	
     	// var newTextBoxDiv = $(document.createElement('div')).attr("id", 'row_box_0_2').attr("style", 'margin-bottom: 10px;float: left;padding-bottom:2px;    margin-top: 18px;');
     	// (document.createElement('div')).attr("id", 'row_box_'+i+'_'+counter1).attr("style", 'margin-bottom: 10px;float: left;padding-bottom:2px;margin-top: 18px;')
     	
     	// var newTextBoxDiv = $("#"+after_div).insertafter('<div id="row_box_'+i+'_'+counter1+'" style="margin-bottom: 10px;float: left;padding-bottom:2px;margin-top: 18px;"></div>');
     	var after_div_new ="'"+"row_box_"+i+"_"+counter1+"'";
     	// alert(after_div);
     	// alert(after_div_new);
     	var newTextBoxDiv =  document.querySelector("#"+after_div);
     	// alert(after_div);
    	ele = document.createElement("div");
		// ele.id = "row_box_"+i+'_'+counter1;
		ele.id = "row_box_"+i+'_'+counter1;
		ele.style = "margin-bottom: 10px;float: left;padding-bottom:2px;margin-top: 18px;";
		newTextBoxDiv.parentNode.insertBefore(ele, newTextBoxDiv.nextSibling);
     	//alert(newTextBoxDiv);
     	
		$('#row_box_'+i+'_'+counter1).html(
			'<div class="" style="float: left;width:7%;clear: both;"><input id="calculate_row_'+i+'_' + counter1 + '" name="numbers[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:75%;" class="row_total" onkeyup="numbers_total('+i+','+counter1+','+first_id+')" value=""></div>'
			+'<div style="float:right;margin-top: -23px; "><a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child('+0+', '+year +','+month+','+day+','+first_id+','+after_div_new+');" > + Add Product </a>	</div>'
			+'<div class="" style="float: left;width: 30%;padding-right: 4px "><div class="select select-block ">'
			+'<?php if($source=='boyzweekend'){ ?><?php $product_data = "SELECT * FROM products WHERE source='$source' ORDER BY title ASC "; $product_result = mysql_query($product_data);?>'
					+'<select id="product_'+i+'_' + counter1 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+i+','+counter1+','+first_id+')">'
					+'<option value= "">Select Product</option>'
					+'<?php while($product_info = mysql_fetch_array($product_result)){ ?>'
					+'<option value= "<?php echo $product_info[id];?>">'
					+"<?php echo $product_info[title]; ?>"
					+'</option>'
					+'<?php } ?> '
					+'</select><?php }else{?>'
					+'<select id="product_'+i+'_' + counter1 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+i+','+counter1+','+first_id+')" >'
				     +'</select><?php } ?>'
			+'</div></div>'
			+'<div class="select select-block " style="float: left;width: 7%; 	padding-right: 10px;"><select id="from_time_'+i+'_' + counter1 + '" class="from_time" name="from_time[]"style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time From</option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
					+'<div class="select select-block " style="float: left;width: 7%; 	padding-right: 10px;"><select id="to_time_'+i+'_' + counter1 + '" class="to_time" name="to_time[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time To</option>'
					+'<option value="17:17:17"></option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
		
			+'<div class="" style="float: left;width: 7%;	padding-right: 10px; "><input id="price_'+i+'_'+counter1 + '" name="price[]" onchange="newTotal_price('+i+','+counter1+','+first_id+')" placeholder="Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="price_class"></div>'
			+'<div class="" style="float: left;width: 7%;	padding-right: 10px; "><input id="supplier_price_'+i+'_'+counter1 + '" name="supplier_price[]" onchange="newsupplier('+i+','+counter1+','+first_id+')"  placeholder="Supplier Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="supplier_price_class"></div>'
			+'<div class="" style="float: left;width: 7%;	padding-right: 10px;"><input id="total_price_'+i+'_' + counter1 + '" readonly name="total_price[]" class="total_price_class" placeholder="Total Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"></div>'
			+'<div class="" style="float: left;width: 18%;	padding-right: 10px; "><textarea id="itinerary_package_additional_instructions_'+i+'_' + counter1 + '" name="itinerary_package_additional_instructions[]"   placeholder="Additional Instructions here..." style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="itinerary_package_additional_instructions_class"></textarea></div>'
		
			+'<div class="" style="float: left;width: 2%;	padding-right: 1px;margin-left: -20px;"><input type="checkbox" id="check_price_' + counter1 + '" name="check_price1" onclick="check_uncheck_price('+counter1+');"  style="height: 15px;width: 15px;margin-top: 6px;margin-left:33px;"><input type="hidden" name="check_price[]" id="check_price_hidden_'+counter1+'" value="0"> </div>'
			
			+'<div style="float: left;width: 1%;text-align: center;margin-left:32px;margin-top:5px;">'
			+'<img class="remove_location_button"  title="Remove" onclick="deleteRow('+i+','+counter1 +','+first_id+')" style="cursor:pointer;" id="remove_btn_'+i+'_'+ counter1 + '" src="../images/icons/no.png"><input type="hidden" id="on_date' + counter1+ '" name="on_date[]" value="'+on_date+'">'
			
			+'</div>'

			);
		// newTextBoxDiv.prependTo("#total_div_"+i);
	 // $("#total_div_"+i).before(newTextBoxDiv);
	   <?php 
	 	if($source=='girlzweekend'){?>
	 	
	 		fill_product(i,counter1,first_id);
	 	<?php } ?>

		$( '#TextBoxDiv'+i ).focus();
		counter1++;
		first_id++;
		
	}
	// close for child add more products
	//for remove option
	function deleteRow(rmv,row_no,first_id) 
	{
		// alert(rmv);alert(row_no);
		var x=rmv+'_'+row_no;
		//alert(x);
		$("#row_box_" + x).remove();
        subtotal_datevise();
        grandtotal_datewise();
        subtotal_datevise_for_multi_dates(first_id);
        subtotal_datevise_supplier();
		grandtotal_datewise_supplier();
		subtotal_datevise_for_multi_dates_supplier(first_id);
	}
</script>     
   
<style>
	input, textarea, select {
		font-family: inherit;
		font-size: inherit;
		font-weight: inherit;/
		line-height: 25px;
		padding-left: 10px;
	}
	table {
		border-collapse: inherit;
		border-spacing: 10px;
	}
	.btn_create {
		padding: 10px;
		text-transform: capitalize;
		font-size: 20px;
		color: #1697C9;
		font-weight: bold;
		cursor: pointer;
	}
</style>
<!-- modules/itinerary/create_itinerary.php -->
<form action="modules/itinerary/create_itinerary.php" method="post" enctype="multipart/form-data">
	<!-- _old_13_07_17 -->
	<table cellspacing="10" style="display:inline-flex;">
		<?php $page['title'] = 'Create an Itinerary';?>

		
		<tr >
			<td>Dates:</td>
			<td>
				<input id="from_date" required="true" type="date" style="padding-left: 10px;" name="from_date" onChange="days_between()"  placeholder="from yyyy-mm-dd" /> 
				&nbsp;to&nbsp;
				<input id="to_date"   type="date" style="padding-left: 0px;" name="to_date"  onChange="days_between()"  placeholder="to yyyy-mm-dd"/>
			</td>
		</tr>
		<tr>
		<?php if($source=='boyzweekend'){?>

			<td>Stags Name:</td>

		<?}else{?>

			<td>Hens Name:</td>

		<?} ?>
			<td>
				<input id="stags_name" required="true" type="text" name="stags_name" size="47" placeholder="<?php if($source=='boyzweekend'){ echo 'Stags Name';}else{ echo 'Hens Name';} ?>" value="<?php if($data_from_copy['stags_name']!=''){ echo $data_from_copy['stags_name'];} ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Clients Name:</td>
			<td>
				<input id="bestmans_name" required="true" type="text" name="bestmans_name" size="47" placeholder="Clients Name" value="<?php if($data_from_copy['bestmans_name']!=''){ echo $data_from_copy['bestmans_name'];} ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Client Ph #:</td>
			<td>
				<input id="clients_phone_number"  type="text" name="clients_phone_number" size="47" placeholder="Client Phone Number" value="<?php if($data_from_copy['clients_phone_number']!=''){ echo $data_from_copy['clients_phone_number'];} ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Venue:</td>
			<td>
				<input id="venue" required="true" type="text" name="venue" size="47" placeholder="In and around Taupo" value="<?php if($data_from_copy['venue']!=''){ echo $data_from_copy['venue'];} ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Accommodation:</td>
			<td>
				<input id="accommodation" required="true" type="text" name="accommodation" size="47" onchange="show_hide_no_of_nights();" placeholder="Backpacker" value="<?php if($data_from_copy['accommodation']!=''){ echo $data_from_copy['accommodation'];} ?>"/> 
			</td>
		</tr>
		<!-- style="display:none;margin-top:-3px;" -->
		
		<tr id="for_no_of_nights" <?php if($data_from_copy['accommodation']!=''){ echo "style='display:table-row;margin-top:-3px;'"; }else{ echo "style='display:none;margin-top:-3px;'"; } ?> >
			<td>Number of Nights:</td>
			<td>
				<select id="number_of_nights"  name="number_of_nights">
					<option value="">Select Number of Nights</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>Transport:</td>
			<td>
				<input id="transport" required="true" size="47" placeholder="Transport" type="text" name="transport" value="<?php if($data_from_copy['transport']!=''){ echo $data_from_copy['transport'];} ?>" /> 
			</td>
		</tr>
		<tr>
			<td>Number:</td>
			<td>
				<input id="number_of_persons"   type="text" placeholder="Number of Persons" name="number_of_persons" size="47" onkeyup="checkNAN()"  value=""/> <p style="color:red" id="Error_num"></p>
				
			</td> 
		</tr> 
		<tr>
			<td colspan="2">
    	<div id='TextBoxesGroup' ></div>  
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<table style="width:125%;margin-bottom: 15px;">
					<tr>
						<td>
				<!--add grand total here  -->
				<div  style="margin-left:506px;display: inline-block;" id="show_gtotal_div"><strong>Grand Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' id='grandpricetotal' class='grandpricetotal' name='grandpricetotal' style='width:78px;padding-left:1px;padding:2px;' disabled>&nbsp;<input type='text' id='grandsuppliertotal' class='grandsuppliertotal' name='grandsuppliertotal' style='width:78px;padding-left:1px;padding:2px;' disabled>&nbsp;<input type='text' id='grandtotal' class='grandtotal' name='grandtotal' style='width:78px;padding-left:1px;padding:2px;' disabled></div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<br/>
				<p><b>Notes: Happy partying.............</b></p>
				<p>
				Please keep in mind that entry to all of the above venues is at the suppliers’ discretion.<br/>

				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- If you are too intoxicated, they have the right to refuse entry.<br/>

				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- If you are below a respectable dress standard, they have the right to refuse entry.<br/>

				Please read our terms and conditions attached with this email or on our website.</p>
			</td>
		</tr>
		<tr><td colspan="2"></td></tr>
		<tr align="center">
			<td colspan="2">
				<?php
				$source ='';
				$source_url_param ='';
				if(isset($_GET['source']))
				{ 
					$source = $_GET['source'];
					$source_url_param = "&source=$source";
				}
				?>
				<input type="hidden"  name="source" id="source" value="<?php echo $source ;?>"/>
				<input type="submit" class="btn_create" name="create" value="Create"/>

			</td>
		</tr>
	</table>
</form>
<?php include('template/generic/page-footer.php'); ?>
<?php include('template/generic/footer.php'); ?>	
<script type="text/javascript">
function show_hide_no_of_nights()
{

		var accommodation=document.getElementById("accommodation").value;
		if(accommodation!='')
		{
			// alert('yes');
			 document.getElementById("for_no_of_nights").style.display = 'table-row';

		}
		else
		{
			// alert('no');
			 document.getElementById("for_no_of_nights").style.display = 'none';


		}

}

</script>
<script type="text/javascript">
//commented
		// $(document).ready(function(){

		// $('#number_of_persons').keyup(function(){$('.row_total').val($(this).val());});

		// });
//commented

// function show_on_date_click(){
// var number_of_persons=$("#number_of_persons").val();	
// 	$(".row_total").val(number_of_persons);
// }

// $(document).ready(function(){

// $('#to_date').click(function(){$('.row_total').val($(this).val());});

// });
	
function subtotal_datevise()
{
	//alert(first_id);alert(second_id);alert(third_id);
	var total_for_price=0;
	$( "#TextBoxDiv0").find(".total_price_class").each(function() {
  		var sum_for_price=$( this ).val();
  		
  		if(sum_for_price!=''){
  			total_for_price=parseFloat(total_for_price)+parseFloat(sum_for_price);
			}
	});
	$( "#total_div_0").find(".sum_total").val(total_for_price);	
	var total_for_rate=0;
	$( "#TextBoxDiv0").find(".price_class").each(function() {
  		var sum_for_rate=$( this ).val();
  		if(sum_for_rate!=''){
  			total_for_rate=parseFloat(total_for_rate)+parseFloat(sum_for_rate);
  	    	}
	});
	// alert(total_for_rate);
	$( "#total_div_0").find(".price_total").val(total_for_rate);	

		
   
}

function subtotal_datevise_supplier()
{
	var total_for_supplier=0;
	$( "#TextBoxDiv0").find(".supplier_price_class").each(function() {
  		var sum_for_supplier=$( this ).val();
  		if(sum_for_supplier!=''){
  			total_for_supplier=parseFloat(total_for_supplier)+parseFloat(sum_for_supplier);
  	    	}
	});
	$( "#total_div_0").find(".supplier_price_total").val(total_for_supplier);
}
</script>
