<?php
ini_set('session.gc_maxlifetime', 10800);
$page['title'] = 'List Itinerary';
include('template/generic/header.php');
include('template/generic/navigation.php');

if(!isset($_REQUEST['source'])){ ?>


  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<div class="container" style="margin-top: 10%;">


<div class="row">
  <div class="col-md-4"></div>
  <div class="col-md-2">
    <div class="thumbnail" style="border: none !important;">
      <a href="http://boyzweekend.co.nz/admin/index.php?section=itinerary&page=1&ipp=All&act=view&source=boyzweekend">
        <img class="img-responsive press-button" src="http://boyzweekend.co.nz/images/_logo2.jpg" alt="Lights" >
        
      </a>
    </div>
  </div>
  <div class="col-md-2">
    <div class="thumbnail" style="border: none !important;">
      <a href="http://boyzweekend.co.nz/admin/index.php?section=itinerary&page=1&ipp=All&act=view&source=girlzweekend">
        <img class="img-responsive press-button2" src="http://www.girlzweekend.co.nz/images/_logo.jpg" alt="Lights" style="width: 100%;height: 150px;">
        
      </a>
    </div>
  </div>
</div>
</div>


<style>
.gt-footer{
  
    position: absolute;
    bottom: 0;

}
.press-button2:active , .press-button2.active {background-color: #417cb8;box-shadow: 0 5px #27496d;transform: translateY(5px);}
.press-button:active , .press-button.active {background-color: #417cb8;box-shadow: 0 5px #27496d;transform: translateY(5px);}
.press-button2{background-color: transparent;
    border: 2px solid #6d4727;
    border-radius: 15px;
    box-shadow: 0 9px rgba(169, 68, 66, 0.88);}

.press-button{background-color: transparent;border: 2px solid #27496d;border-radius: 15px;box-shadow: 0 9px #27496d;}
</style>


<?php }else{



//for status change automatically
$current_date=date('Y-m-d');
$query_for_status="SELECT * FROM `itinerary` WHERE to_date<"."'$current_date'";
$result_for_status=$database->query($query_for_status);

while($data=mysql_fetch_assoc($result_for_status))
{
	$id_update=$data['id'];
	$query_update_status="UPDATE FROM `itinerary` SET `status`='3' WHERE id=".$id_update;
}
//for status change automatically endssss
$source ='';
$source_url_param ='';
if(isset($_GET['source']))
{ 
	$source = $_GET['source'];
	
}
$source_url_param = "&source=$source";
if($_GET['search'] != '')
{ 

	if($_GET['status_dropdown']=='all')
	{
		$filter .= " WHERE ( stags_name LIKE '%" . addslashes(trim($_GET['search'])) . "%' OR id LIKE '%". addslashes(trim($_GET['search'])) . "%' OR bestmans_name LIKE '%". addslashes(trim($_GET['search'])) . "%' OR venue LIKE '%". addslashes(trim($_GET['search'])) . "%' OR accommodation LIKE '%". addslashes(trim($_GET['search'])) . "%' ) AND source LIKE '".$source."'";
	}else
	{
		$filter .= " WHERE ((stags_name LIKE '%" . addslashes(trim($_GET['search'])) . "%' OR id LIKE '%". addslashes(trim($_GET['search'])) . "%' OR bestmans_name LIKE '%". addslashes(trim($_GET['search'])) . "%' OR venue LIKE '%". addslashes(trim($_GET['search'])) . "%' OR accommodation LIKE '%". addslashes(trim($_GET['search'])) . "%') AND status=".$_GET['status_dropdown']." ) AND source LIKE '".$source."'";
	}
	
}
if($_GET['status_dropdown']!='' && $_GET['search'] == '')
{
		if($_GET['status_dropdown']!='all')
		{
			$filter .= " WHERE status=".$_GET['status_dropdown'] ." AND source LIKE '".$source."' ";
		}else
		{
			$filter .= "";
		}
		
	
	
}

if($filter!=""){
	$filter .="  ";
}else{
	$filter .=" WHERE source LIKE '".$source."' ";
}


// Pagination setup
$q = "SELECT COUNT(*) FROM itinerary".$filter;
 //print_r($q);
 //die(); 
$query = $database->query($q);
$total_search_results = mysql_result($query, 0);

$pages = new Paginator;
$pages->items_total = $total_search_results;
$pages->mid_range = 2;
$pages->paginate();

// Items Setup
$items = array();

$q = "SELECT * FROM itinerary".$filter." ORDER BY created_on DESC";

echo '<input type="hidden" value="'.$q.'"/>';
// Append Query

$q .= "$pages->limit";
$query = $database->query($q);
if($query != FALSE)
{	
	while($result = mysql_fetch_assoc($query))
	{
		$date1=date_create($result['from_date']);
		$result['from_date'] = date_format($date1,"d M Y");
		$date2=date_create($result['to_date']);
		$result['to_date'] = date_format($date2,"d M Y");
		$date3=date_create($result['created_on']);
		$result['created_on'] = date_format($date3,"d M Y  h:i:s a");
				$items[] = $result;
	}
}

// Business Logic

?>
<h1>List Itinerary</h1>

<?php

// Success Message handler -> import into utility class
if($_SESSION['success_message'] != '')
{
	echo '<p class="gt-success">'.$_SESSION['success_message'].'</p>';
	unset($_SESSION['success_message']);
}

?>
<style type="text/css">
.table-title select {
 padding: 2px 3px 7px 0px !important;
	}
</style>
<form action="" method="get">
	<table width="110%" cellpadding="0" cellspacing="0" class="table-title" />
<tr><td align=""><?php echo 'Page: '.$pages->current_page.' of '.$pages->num_pages.' - '.$pages->display_pages(); ?></td>
<td align="" width="160"><?php echo $pages->display_items_per_page(); ?></td>
<td>
		<input type="hidden" name="section" value="itinerary" />
		<input type="hidden" name="page" value="1" />
		<input type="hidden" name="ipp" value="All" />
		<input type="hidden" name="act" value="view" />
		<input type="hidden" name="source" value="<?php echo $source;?>" />
		<span style="">Status:</span>
		<select name="status_dropdown" id="status_dropdown" style="padding: 2px 3px 7px 0px;">
		    <option value="all">All</option>
	        <option value="0" <?php if($_GET['status_dropdown'] =='0'){echo ' selected';}?> >Quoted Jobs</option>
			<option value="1" <?php if($_GET['status_dropdown'] =='1'){echo ' selected';}?>>Booked Jobs</option>
			<option value="2" <?php if($_GET['status_dropdown'] =='2'){echo ' selected';}?>>Finalised Jobs</option>
			<option value="3" <?php if($_GET['status_dropdown'] =='3'){echo ' selected';}?>> Completed Jobs</option>
		</select>
		<input type="text" name="search" value="<?php echo $_GET['search']; ?>" style="padding: 2px 3px 7px 0px; border: 1px solid #cccccc;" />&nbsp;<button type="submit" class="submitBtn"><span style="padding-left: 12px;width: 80px;">Search Itinerary</span></button>
</td>
<td><a href="?section=itinerary&act=view_itinerary<?php echo $source_url_param; ?>" style="float:right;">Create Itinerary</a></td>
</tr>
</form>	

<form action="modules/itinerary/view_itinerary_detail.php<?php echo $source_url_param; ?>" method="post" id="view_form ">
<input type="hidden" name="subdelete" value="1" />
<table width="1010" cellpadding="0" cellspacing="0" style="margin: 6px 0 0 0;" class="admin-view-table" />
<tr>
<!-- <th class="leftcol"><img src="../images/icons/no.png" style="cursor: pointer;" onclick="confirmdelete('deleteform')" /></th> -->

<th class="leftcol" ><input type="checkbox" style="vertical-align: middle;" id="checkAll"/>Check All</th> 
<th>Dates</th>
<?php if($source=='boyzweekend'){?>

<th>Stags Name</th>

<?}else{?>

<th>Hens Name</th>

<?} ?>
<th>Clients Name</th>
<th>Venue</th> 
<th>Accommodation</th>
<th>Transport</th>
<th>Number of Persons</th>
<th>Status</th>
<th>Created On</th>
<th>View Detail</th>
<th>Edit</th>
<th>Delete</th>
</tr>

<?php
if($items == array())
{
	?>
<tr>
<td colspan="13" style="text-align:center" class="leftcol rightcol">
<span style="font-size: 14px; color: #333333; font-style:italic;">No matching data</span>
</td>   
</tr>
    <?php
} else {
foreach($items as $result)
{
	//echo '<tr><td class="leftcol"><input type="checkbox" name="delete[]" value="' . $result['id'] . '" /></td>';
?>

<td class="leftcol"><input type="checkbox" class="checkBoxClass" name="delete[]" value="<?php echo $result['id'] ;?>" /></td>
<td><?php echo $result['from_date']." to ".$result['to_date'];?></td>
<td><?php echo $result['stags_name'];?></td>
<td><?php echo $result['bestmans_name'];?></td>
<td><?php echo $result['venue'];?></td>
<td><?php echo $result['accommodation'];?></td>
<td><?php echo $result['transport'];?></td>
<td><?php echo $result['number_of_persons'];?></td>
<td>
	<select name="status" id="<?php echo $result['id']; ?>" class="status">
		<option value="0" <?php if($result['status']==0){ echo 'selected="selected"';}?>>Quoted Jobs</option>
		<option value="1" <?php if($result['status']==1){ echo 'selected="selected"';}?>>Booked Jobs</option>
		<option value="2" <?php if($result['status']==2){ echo 'selected="selected"';}?>>Finalised Job</option>
		<option value="3" <?php if($result['status']==3){ echo 'selected="selected"';}?>>Completed Job</option>
	</select>
</td>
<td><?php echo $result['created_on'];?></td>
<td><a href="?section=itinerary&act=view_itinerary_detail&id=<?php echo $result['id'];?><?php echo $source_url_param; ?>"> View</a>
</td>
<td><a href="?section=itinerary&act=edit_itinerary&id=<?php echo $result['id'];?><?php echo $source_url_param; ?>"> Edit</a></td>
<td style="text-align:center;"><a href="?section=itinerary&act=delete_itinerary&id=<?php echo $result['id']; ?><?php echo $source_url_param; ?>"  onclick="return confirm('Once you confirm this action can not be undo. Are you sure to delete ?')">
	<img src="../images/icons/no.png" style="cursor: pointer;"/></a></td>
</tr>
<?php }
}
echo '</table>
</form>';?>
<script src="../js/jquery.min.js"></script>
<div class="admin-view-table-footer" style="padding-top: 10px; width: 110% !important;">
	<span onClick="deleteCommon_all()" style="cursor: pointer; padding-left:5px;" ><b>Delete Selected</b></span>
</div> 
<?php echo '<div class="admin-view-table-footer" style="width: 110% !important;"></div>';
// <a href="?action=view_user&user='.$result['username'].'">View</a>
?>   
<script type="text/javascript">
// <!--
// 	function confirmdelete(formid){
// 		var answer = confirm("Really delete?")
// 		if (answer){
// 			document.forms[formid].submit();
// 		}	
// 	}
// //-->
</script>
<script type="text/javascript">

	/* function confirmdelete(formid){
		var answer = confirm("Really delete?")
		if (answer){
			document.forms[formid].submit();
		}	
	} */
	

$(function(){
	
	$("#checkAll").change(function () {
		$(".checkBoxClass").attr('checked', this.checked);
	});
});

function deleteCommon_all()
{
	var page1 = '?section=itinerary&act=delete_itinerary';

	  var multipleValues = "";
	 
	  $('.checkBoxClass:checked').each(function(i,selected){	
		if(i!=0)
			multipleValues = multipleValues + ",";
		multipleValues = multipleValues + $(selected).val();
		  
	  });	 
	  if(multipleValues=='')
	  {
		  alert('Please select atleast one record');
		  return false;
	  }
	  if(confirm('Once you confirm this action can not be undo. Are you sure to delete ?'))
	  {
			  //	alert(page1+'&id='+multipleValues);
		 window.location = page1+'&id='+multipleValues;


	  }
}
</script>
<script type="text/javascript">

var old_select_value=$(".status option:selected").val();
$(".status").change(function(){
	
	var option=$(this).val();
	var result = confirm("Are you sure you want to change status?");

		
		if (result)
		{
  		   var Id=$(this).attr("id");
		   var status_option=$(this).val();
		   // alert(status_option);
           var url = "../admin/?section=itinerary&act=itinerary_status";
				$.ajax({
			           type: "GET",
			           url: url,
			          
						data: 'id='+ encodeURIComponent(Id) + '&option='+ encodeURIComponent(status_option),
			          
			             success: function(data)
			              {
			           	    if(data==1)
			           	      {
			           	      	alert("Status has been changed.");
			           	      }
			              }	
			           });
			    
		 }else
		 {
		 	$(this).prop("selectedIndex",old_select_value);
		 }
		 

	
});

</script>
<?php } //else end for check source exist or not ?>
<?php include('template/generic/page-footer.php'); ?>
<?php include('template/generic/footer.php'); ?>




