<?php
ini_set('session.gc_maxlifetime', 10800);
$page['title'] = 'Edit an itinerary';
include('template/generic/header.php');
include('template/generic/navigation.php'); 
$source ='';
$source_url_param ='';
if(isset($_GET['source']))
{ 
	$source = $_GET['source'];
	
}
$source_url_param = "&source=$source";
?>
<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->

<!-- jQuery library -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->

<!-- Latest compiled JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

<div class="admin-submenu buttons">
  <a href="../admin/?section=itinerary&act=view<?php echo $source_url_param;?>">Back to list</a>
  <div style="clear: both;"></div>
</div>
<h1 align="center" style="color: black;font-size: 36px;">Edit an Itinerary</h1>

<?php
// Success Message handler -> import into utility class
if($_SESSION['success_message'] != '')
{
	echo '<p class="gt-success">'.$_SESSION['success_message'].'</p>';
	unset($_SESSION['success_message']);
}
?>
<link href="boyz_026.ico" rel="shortcut icon" type="image/x-icon" />    
<script src="../js/jquery.min.js"></script>

<script type="text/javascript">
function findTotal(){
    var arr_for_price = document.getElementsByName('total_price[]');
    // alert(arr);
    var total_of_price=0;
    for(var i=0;i<arr_for_price.length;i++){
        if(parseInt(arr_for_price[i].value))
            total_of_price += parseInt(arr_for_price[i].value);
    }
    document.getElementById('grandtotal').value = total_of_price;
}
function findPriceTotal(){
    var arr_for_rent = document.getElementsByName('price[]');
    // alert(arr);
    var total_of_rent=0;
    for(var i=0;i<arr_for_rent.length;i++){
        if(parseInt(arr_for_rent[i].value))
            total_of_rent += parseInt(arr_for_rent[i].value);
    }
    document.getElementById('grandpricetotal').value = total_of_rent;
}
function findSupplierTotal(){
    var arr_for_supplier = document.getElementsByName('supplier_price[]');
    // alert(arr);
    var total_of_supplier=0;
    for(var i=0;i<arr_for_supplier.length;i++){
        if(parseInt(arr_for_supplier[i].value))
            total_of_supplier += parseInt(arr_for_supplier[i].value);
    }
    document.getElementById('grandsuppliertotal').value = total_of_supplier;
}
    </script>

<script type="text/javascript">
	
function fill_product(pid1,pid2,first_id)
{

			// alert('test'+pid1+" 111 "+pid2+" 222 "+first_id);

	$.ajax({

             url:'index.php?section=itinerary&act=fill_products',
             success: function(result)
              {

		 	    var product_id="product_"+pid1+"_"+pid2;
	           	document.getElementById(product_id).innerHTML = result;
              }
           });
}

</script>
 
<script>
	function checkNAN(){
		//alert();
		$(".row_total").val(''); //for null all numbers 
		var number1=document.getElementById("number_of_persons").value;
//commented
		// if(number1<0 ){
		// 	document.getElementById("Error_num").innerHTML="Please check your number";
		// 	}else if(number1 == 0){
				
		// 		document.getElementById("number_of_persons").value="1";
		// 	}else{
		// document.getElementById("Error_num").innerHTML="";
	//commented
			
			var price1=[] ;
			var idr=[];
	        $('.price_class').each(function(){
		       		 	//var value = $(this).val();
		       		var value = $(this).val();
						price1.push(value);
	       		 });
	        $('.total_price_class').each(function(){
		       		 	//var value = $(this).val();
		       		var total_price_id = $(this).attr('id');
						idr.push(total_price_id);
	       		 });

				




	       allfield_changed=0;
	        for(var i=0;i<price1.length;i++)
	        {
	        	var price_val = price1[i];
	        	var total_price_idr = idr[i];
	        	$('#'+total_price_idr).val(price_val*number1);
				allfield_changed=1;
		        }
	        //subtotal_datevise();

	        if(allfield_changed==1){

	        $('.TextBoxDiv_class').each(function(){
		       		 	//var value = $(this).val();
		       		var TextBoxDiv_id = $(this).attr('id');
		       		var table_ids = TextBoxDiv_id.split("_");
						first_id = table_ids['1'];
						second_id = table_ids['2'];
						third_id = table_ids['3'];
						//alert(first_id);
						subtotal_datevise(first_id,second_id,third_id);
	       		 });
	
	        }
	        grandtotal_datewise();
        	grandtotal_pricewise();
        	// grandtotal_supplierwise();



		// }//commented else
	}


	
function newTotal_price(pid1,pid2,dt,first_id,second_id,third_id){
			 	
			 	var price="price_"+pid1+"_"+pid2+"_"+dt;
				var price_data=document.getElementById(price).value;
			 	var number_of_persons=document.getElementById("number_of_persons").value;

			 	var no_of_person_row="calculate_row_"+pid1+"_"+pid2+"_"+dt;
	var no_of_person_row_data=document.getElementById(no_of_person_row).value;

	if(no_of_person_row_data!='')
	{
		document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=price_data*no_of_person_row_data;
	}else
	{
		document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=price_data*number_of_persons;	
	}
			 	
			 	subtotal_datevise(first_id,second_id,third_id);
			 	grandtotal_datewise();
        		grandtotal_pricewise();
        	

			 }



function productPrice(pid1,pid2,dt,first_id,second_id,third_id){

	// alert(first_id+""+second_id+""+third_id);
	// alert("price_"+pid1+"_"+pid2+"_"+dt);
	 var product_id="product_"+pid1+"_"+pid2;
	 var product_by_id="&product_by_id="+document.getElementById(product_id).value;
	 var number_of_persons=document.getElementById("number_of_persons").value;

	 var no_of_person_row="calculate_row_"+pid1+"_"+pid2+"_"+dt;
	 var no_of_person_row_data=document.getElementById(no_of_person_row).value;
	 // alert(no_of_person_row_data);
	//alert(product_by_id);
		  $.ajax({
            type:'GET', 	
            url:'index.php?section=itinerary&act=get_price<?php echo $source_url_param; ?>',
            data: product_by_id,
                
            success: function(result){
            	// alert(response);
            	var str_split_price = result.split("#");
            	var response=str_split_price[0];
            	var supplier_price_from_ajax=str_split_price[1];
            	
            	// alert(response);
            	// alert(supplier_price_from_ajax);
            	if($.isNumeric(supplier_price_from_ajax))
            	  {
					document.getElementById("supplier_price_"+pid1+"_"+pid2+"_"+dt).value=supplier_price_from_ajax; 
            	   }else
            	   {
            	   	supplier_price_from_ajax='0';
            	   	document.getElementById("supplier_price_"+pid1+"_"+pid2+"_"+dt).value=supplier_price_from_ajax;
            	   }
            	 if($.isNumeric(response))
            	  {
				
                             document.getElementById("price_"+pid1+"_"+pid2+"_"+dt).value=response; 
                             document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=response*number_of_persons;
                             if(no_of_person_row_data!='')
                             {
                             document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=response*no_of_person_row_data;	
                             }
                             subtotal_datevise(first_id,second_id,third_id);
                             grandtotal_datewise();
        					 grandtotal_pricewise();
        					 grandtotal_supplierwise();
	                         subtotal_datevise_supplier(first_id,second_id,third_id);
               				// $("#price").html(response);
            	 }
            	 else
            	 {
            	 		response="NaN";
            	 			document.getElementById("price_"+pid1+"_"+pid2+"_"+dt).value=response; 
                             document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=response*number_of_persons;
                             if(no_of_person_row_data!='')
                             {
                             document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=response*no_of_person_row_data;	
                             }
                             subtotal_datevise(first_id,second_id,third_id);
                             grandtotal_datewise();
        					 grandtotal_pricewise();
        					 grandtotal_supplierwise();
	                         subtotal_datevise_supplier(first_id,second_id,third_id);
               				// $("#price").html(response);

            	 }
            }
        });



	}



	function numbers_total(pid1,pid2,dt,first_id,second_id,third_id)
{
	var number_of_persons=document.getElementById("number_of_persons").value;
	var price="price_"+pid1+"_"+pid2+"_"+dt;
	// alert(price);
	var price_data=document.getElementById(price).value;
	// alert(price_data);

	var no_of_person_row="calculate_row_"+pid1+"_"+pid2+"_"+dt;
	var no_of_person_row_data=document.getElementById(no_of_person_row).value;

   if(isNaN(no_of_person_row_data) || no_of_person_row_data==0 )
	{
		// alert('Please insert number');
		document.getElementById(no_of_person_row).value='';
	}


	if($.isNumeric(no_of_person_row_data)==''){
     
     	if(number_of_persons!='')
     	{
     		no_of_person_row_data=number_of_persons;
     	}else{
     		no_of_person_row_data=0;	
     	}
           
    		 document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=price_data*parseInt(no_of_person_row_data);
	 
	            subtotal_datevise(first_id,second_id,third_id);
                grandtotal_datewise();
        	    grandtotal_pricewise();
      
       }else
       {
             document.getElementById("total_price_"+pid1+"_"+pid2+"_"+dt).value=price_data*parseInt(no_of_person_row_data);
	 				
	 			subtotal_datevise(first_id,second_id,third_id);
                grandtotal_datewise();
        		grandtotal_pricewise();
        		
       }


	
}

function subtotal_datevise(first_id,second_id,third_id)
{	
	// alert(first_id+sec);alert(second_id);alert(third_id);
	// alert("#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id);
	var total_for_price_1=0;
	$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".total_price_class").each(function() {
  		var sum_for_price_1=$( this ).val();
  		
  		if(sum_for_price_1!=''){
  			total_for_price_1=parseFloat(total_for_price_1)+parseFloat(sum_for_price_1);
			}
	});
	
	$( "#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".sum_total").val(total_for_price_1);

	
	var total_for_rate_1=0;
	$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".price_class").each(function() {
  		var sum_for_rate_1=$( this ).val();
  		if(sum_for_rate_1!=''){
  			total_for_rate_1=parseFloat(total_for_rate_1)+parseFloat(sum_for_rate_1);
  	    	}
	});
	$( "#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".price_total").val(total_for_rate_1);

	
   
}
function subtotal_datevise_supplier(first_id,second_id,third_id)
{
	var total_for_supplier_2=0;
	$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".supplier_price_class").each(function() {
  		var sum_for_supplier_2=$( this ).val();
  		if(sum_for_supplier_2!=''){
  			total_for_supplier_2=parseFloat(total_for_supplier_2)+parseFloat(sum_for_supplier_2);
  	    	}
	});
	$( "#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".supplier_price_total").val(total_for_supplier_2);
}
function grandtotal_datewise(){
			var total_for_price=0;
			$(".total_price_class").each(function() {
 			var sum_for_price=$( this ).val();
 				if(sum_for_price!=''){ 
  					total_for_price=parseFloat(total_for_price)+parseFloat(sum_for_price);
		  			}
				});
			$( ".grandtotal").val(total_for_price);
   
}

function grandtotal_pricewise(){
			var total_for_rate=0;
			$(".price_class").each(function() {
  			var sum_for_rate=$( this ).val();
  				if(sum_for_rate!=''){
  					total_for_rate=parseFloat(total_for_rate)+parseFloat(sum_for_rate);
				}
			});
			$( ".grandpricetotal").val(total_for_rate);
   
}

function grandtotal_supplierwise(){
			var total_for_supplier_3=0;
			$(".supplier_price_class").each(function() {
  			var sum_for_supplier_3=$( this ).val();
  				if(sum_for_supplier_3!=''){
  					total_for_supplier_3=parseFloat(total_for_supplier_3)+parseFloat(sum_for_supplier_3);
				}
			});
			$( ".grandsuppliertotal").val(total_for_supplier_3);
   
}

function newTotalsupplier(pid1,pid2,dt,first_id,second_id,third_id){
	grandtotal_supplierwise();
	subtotal_datevise_supplier(first_id,second_id,third_id);
}
function check_uncheck_price(common_id)
{
	// alert()id="check_price_hidden_'+counter+'"
	//alert(common_id);
	if(document.getElementById("check_price"+common_id).checked)
	{
	document.getElementById("check_price_hidden_"+common_id).value=1;
	}else
	{
	document.getElementById("check_price_hidden_"+common_id).value=0;

	}

}

</script>
<script type="text/javascript">
	var counter1=2;
	
	var counter2=2;
	// new child append code
	function leftPad(number, targetLength) {
    var output = number + '';
		    while (output.length < targetLength) {
		        output = '0' + output;
		    }
		    return output;
		}
		var row_box_new_id=0;
	function newProduct_child(x,day,month,year,y,dt1,after_div)
	{ 
		on_date_concate = year +'-'+month+'-'+day;
		var i=x;
		i = i+1;
		var dt= dt1;



		// alert(after_div);
		// alert("#row_box_count_"+leftPad(day, 2)+'_'+leftPad(month, 2)+'_'+leftPad(year, 2));
		var row_box_new_id = $("#row_box_count_"+leftPad(day, 2)+'_'+leftPad(month, 2)+'_'+leftPad(year, 2)).val();
		// alert(row_box_new_id);
			row_box_new_id++;
		$("#row_box_count_"+leftPad(day, 2)+'_'+leftPad(month, 2)+'_'+leftPad(year, 2)).val(row_box_new_id);
		
		// alert(row_box_new_id);
		var after_div_new ="'"+"row_box_0_"+row_box_new_id+"_"+dt+"'";
		// alert(after_div_new);
     	var newTextBoxDiv =  document.querySelector("#"+after_div);

     	// alert(newTextBoxDiv);
		if(newTextBoxDiv==null)
		{
			var newTextBoxDiv = $(document.createElement('div')).attr("class","row_box").attr("id", 'row_box_0_'+row_box_new_id+'_'+dt).attr(
         	"style", 'margin-bottom: 10px;float: left;');
			// alert('test');
			// alert(newTextBoxDiv);
				newTextBoxDiv.after().html(
			'<div class="check_row_box" style="float: left;width:7%;clear: both;"><input id="calculate_row_'+i+'_'+counter1 +'_'+dt+'" name="numbers[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:75%;" class="row_total" onkeyup="numbers_total('+i+','+counter1+','+dt+','+x+','+y+','+dt+')" value=""></div>'
			+'<div style="float:right;margin-top: -23px; " class="check_row_box"><a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child('+x+', '+day +','+month+','+year+','+y+','+dt1+','+after_div_new+');" > + Add Product </a>	</div>'
			+'<div class="check_row_box" style="float: left;width: 30%; "><div class="select select-block check_row_box">'
			+'<?php if($source=='boyzweekend'){ ?><?php $product_data = "SELECT * FROM products WHERE source='$source'  ORDER BY title ASC  "; $product_result = mysql_query($product_data);?>'
					+'<select id="product_'+i+'_' + counter1 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+i+','+counter1+','+dt+','+x+','+y+','+dt+')">'
					+'<option value= "">Select Product</option>'
					+'<?php while($product_info = mysql_fetch_array($product_result)){ ?>'
					+'<option value= "<?php echo $product_info[id];?>">'
					+"<?php echo $product_info[title]; ?>"
					+'</option>'
					+'<?php } ?> '
					+'</select><?php }else{?>'
					+'<select id="product_'+i+'_' + counter1 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+i+','+counter1+','+dt+','+x+','+y+','+dt+')">'
					+'</select><?php }?>'
			+'</div></div>'
			+'<div class="select select-block check_row_box" style="float: left;width: 7%; 	padding-right: 10px;"><select id="from_time_' + counter1 + '" class="from_time" name="from_time[]"style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time From</option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
					+'<div class="select select-block check_row_box" style="float: left;width: 7%; 	padding-right: 10px;"><select id="to_time_' + counter1 + '" class="to_time" name="to_time[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time To</option>'
					+'<option value="17:17:17"></option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'

			+'<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px; "><input id="price_'+i+'_'+counter1 +'_'+dt+'" name="price[]" class="price_class" onblur="findPriceTotal()"  onchange="newTotal_price('+i+','+counter1+','+dt+','+x+','+y+','+dt+')" placeholder="Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="price_class"></div>'
			+'<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px; "><input id="supplier_price_'+i+'_'+counter1 +'_'+dt+'" name="supplier_price[]" class="supplier_price_class"  onchange="newTotalsupplier('+i+','+counter1+','+dt+','+x+','+y+','+dt+')" placeholder="Supplier Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"></div>'
			+'<div class="check_row_box" style="float: left;width: 7%;	padding-right: 14px;"><input  id="total_price_'+i+'_' + counter1 +'_'+dt+'" readonly name="total_price[]" onblur="findTotal()" class="total_price_class" placeholder="Total Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"></div>'

			+'<div class="check_row_box" style="float: left;width: 18%;	padding-right: 10px; "><textarea id="itinerary_package_additional_instructions_'+i+'_' + counter1 +'_'+dt+'" name="itinerary_package_additional_instructions[]"   placeholder="Additional Instructions here..."  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="itinerary_package_additional_instructions_class"></textarea></div>'

			+'<div class="check_row_box" style="float: left;width: 1%;	padding-right: 9px;"><input type="checkbox" id="check_price'+i+'_'+counter1+'_'+dt+'" name="check_price1" onclick="check_uncheck_price(\'' +i+'_'+counter1+'_'+dt+ '\');"  style="height: 15px;width: 15px;margin-top: 6px;margin-left:8px;"><input type="hidden" name="check_price[]" id="check_price_hidden_'+i+'_'+counter1+'_'+dt+'" value="0"></div>'
			
			+'<div class="check_row_box" style="float: left;text-align: center;margin-left:9px;margin-top:5px;">'
			+'<img class="remove_location_button"  title="Remove" onclick="deleteRow('+i+','+counter1 +','+x+','+y+','+dt+','+after_div_new+')" style="cursor:pointer;" id="remove_btn_'+i+'_'+ counter1 + '" src="../images/icons/no.png">'
			+'</div><input type="hidden" id="on_date_' + i + '" name="on_date[]" value="'+on_date_concate+'">');
 			$("#InputBoxDiv_"+x+'_'+y+'_'+dt).before(newTextBoxDiv);


         	// alert();
		}else{
			     	// alert(after_div);
    	ele = document.createElement("div");
		// ele.id = "row_box_"+i+'_'+counter1;
		ele.id = "row_box_0_"+row_box_new_id+'_'+dt;
		ele.style = "margin-bottom: 10px;float: left;padding-bottom:2px;margin-top: 18px;";
		newTextBoxDiv.parentNode.insertBefore(ele, newTextBoxDiv.nextSibling);
		$('#row_box_0_'+row_box_new_id+'_'+dt).attr("class","row_box");

		$('#row_box_0_'+row_box_new_id+'_'+dt).html(
			'<div class="check_row_box" style="float: left;width:7%;clear: both;"><input id="calculate_row_'+i+'_'+counter1 +'_'+dt+'" name="numbers[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:75%;" class="row_total" onkeyup="numbers_total('+i+','+counter1+','+dt+','+x+','+y+','+dt+')" value=""></div>'
			+'<div style="float:right;margin-top: -23px; " class="check_row_box"><a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child('+x+', '+day +','+month+','+year+','+y+','+dt1+','+after_div_new+');" > + Add Product </a>	</div>'
			+'<div class="check_row_box" style="float: left;width: 30%; "><div class="select select-block  check_row_box">'
			+'<?php if($source=='boyzweekend'){ ?><?php $product_data = "SELECT * FROM products WHERE source='$source'  ORDER BY title ASC  "; $product_result = mysql_query($product_data);?>'
					+'<select id="product_'+i+'_' + counter1 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+i+','+counter1+','+dt+','+x+','+y+','+dt+')">'
					+'<option value= "">Select Product</option>'
					+'<?php while($product_info = mysql_fetch_array($product_result)){ ?>'
					+'<option value= "<?php echo $product_info[id];?>">'
					+"<?php echo $product_info[title]; ?>"
					+'</option>'
					+'<?php } ?> '
					+'</select><?php }else{?>'
					+'<select id="product_'+i+'_' + counter1 + '" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice('+i+','+counter1+','+dt+','+x+','+y+','+dt+')">'
					+'</select><?php }?>'
			+'</div></div>'
			+'<div class="select select-block check_row_box" style="float: left;width: 7%; 	padding-right: 10px;"><select id="from_time_' + counter1 + '" class="from_time" name="from_time[]"style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time From</option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'
					+'<div class="select select-block check_row_box" style="float: left;width: 7%; 	padding-right: 10px;"><select id="to_time_' + counter1 + '" class="to_time" name="to_time[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					+'<option value="17:17:17">Time To</option>'
					+'<option value="17:17:17"></option>'
					+'<option value="24:00:00">12:00 AM</option>'
					+'<option value="24:15:00">12:15 AM</option>'
					+'<option value="24:30:00">12:30 AM</option>'
					+'<option value="24:45:00">12:45 AM</option>'
					+'<option value="01:00:00">01:00 AM</option>'
					+'<option value="01:15:00">01:15 AM</option>'
					+'<option value="01:30:00">01:30 AM</option>'
					+'<option value="01:45:00">01:45 AM</option>'
					+'<option value="02:00:00">02:00 AM</option>'
					+'<option value="02:15:00">02:15 AM</option>'
					+'<option value="02:30:00">02:30 AM</option>'
					+'<option value="02:45:00">02:45 AM</option>'
					+'<option value="03:00:00">03:00 AM</option>'
					+'<option value="03:15:00">03:15 AM</option>'
					+'<option value="03:30:00">03:30 AM</option>'
					+'<option value="03:45:00">03:45 AM</option>'
					+'<option value="04:00:00">04:00 AM</option>'
					+'<option value="04:15:00">04:15 AM</option>'
					+'<option value="04:30:00">04:30 AM</option>'
					+'<option value="04:45:00">04:45 AM</option>'
					+'<option value="05:00:00">05:00 AM</option>'
					+'<option value="05:15:00">05:15 AM</option>'
					+'<option value="05:30:00">05:30 AM</option>'
					+'<option value="05:45:00">05:45 AM</option>'
					+'<option value="06:00:00">06:00 AM</option>'
					+'<option value="06:15:00">06:15 AM</option>'
					+'<option value="06:30:00">06:30 AM</option>'
					+'<option value="06:45:00">06:45 AM</option>'
					+'<option value="07:00:00">07:00 AM</option>'
					+'<option value="07:15:00">07:15 AM</option>'
					+'<option value="07:30:00">07:30 AM</option>'
					+'<option value="07:45:00">07:45 AM</option>'
					+'<option value="08:00:00">08:00 AM</option>'
					+'<option value="08:15:00">08:15 AM</option>'
					+'<option value="08:30:00">08:30 AM</option>'
					+'<option value="08:45:00">08:45 AM</option>'
					+'<option value="09:00:00">09:00 AM</option>'
					+'<option value="09:15:00">09:15 AM</option>'
					+'<option value="09:30:00">09:30 AM</option>'
					+'<option value="09:45:00">09:45 AM</option>'
					+'<option value="10:00:00">10:00 AM</option>'
					+'<option value="10:15:00">10:15 AM</option>'
					+'<option value="10:30:00">10:30 AM</option>'
					+'<option value="10:45:00">10:45 AM</option>'
					+'<option value="11:00:00">11:00 AM</option>'
					+'<option value="11:15:00">11:15 AM</option>'
					+'<option value="11:30:00">11:30 AM</option>'
					+'<option value="11:45:00">11:45 AM</option>'
					+'<option value="12:00:00">12:00 PM</option>'
					+'<option value="12:15:00">12:15 PM</option>'
					+'<option value="12:30:00">12:30 PM</option>'
					+'<option value="12:45:00">12:45 PM</option>'
					+'<option value="13:00:00">01:00 PM</option>'
					+'<option value="13:15:00">01:15 PM</option>'
					+'<option value="13:30:00">01:30 PM</option>'
					+'<option value="13:45:00">01:45 PM</option>'
					+'<option value="14:00:00">02:00 PM</option>'
					+'<option value="14:15:00">02:15 PM</option>'
					+'<option value="14:30:00">02:30 PM</option>'
					+'<option value="14:45:00">02:45 PM</option>'
					+'<option value="15:00:00">03:00 PM</option>'
					+'<option value="15:15:00">03:15 PM</option>'
					+'<option value="15:30:00">03:30 PM</option>'
					+'<option value="15:45:00">03:45 PM</option>'
					+'<option value="16:00:00">04:00 PM</option>'
					+'<option value="16:15:00">04:15 PM</option>'
					+'<option value="16:30:00">04:30 PM</option>'
					+'<option value="16:45:00">04:45 PM</option>'
					+'<option value="17:00:00">05:00 PM</option>'
					+'<option value="17:15:00">05:15 PM</option>'
					+'<option value="17:30:00">05:30 PM</option>'
					+'<option value="17:45:00">05:45 PM</option>'
					+'<option value="18:00:00">06:00 PM</option>'
					+'<option value="18:15:00">06:15 PM</option>'
					+'<option value="18:30:00">06:30 PM</option>'
					+'<option value="18:45:00">06:45 PM</option>'
					+'<option value="19:00:00">07:00 PM</option>'
					+'<option value="19:15:00">07:15 PM</option>'
					+'<option value="19:30:00">07:30 PM</option>'
					+'<option value="19:45:00">07:45 PM</option>'
					+'<option value="20:00:00">08:00 PM</option>'
					+'<option value="20:15:00">08:15 PM</option>'
					+'<option value="20:30:00">08:30 PM</option>'
					+'<option value="20:45:00">08:45 PM</option>'
					+'<option value="21:00:00">09:00 PM</option>'
					+'<option value="21:15:00">09:15 PM</option>'
					+'<option value="21:30:00">09:30 PM</option>'
					+'<option value="21:45:00">09:45 PM</option>'
					+'<option value="22:00:00">10:00 PM</option>'
					+'<option value="22:15:00">10:15 PM</option>'
					+'<option value="22:30:00">10:30 PM</option>'
					+'<option value="22:45:00">10:45 PM</option>'
					+'<option value="23:00:00">11:00 PM</option>'
					+'<option value="23:15:00">11:15 PM</option>'
					+'<option value="23:30:00">11:30 PM</option>'
					+'<option value="23:45:00">11:45 PM</option>'
					+'</select></div>'

			+'<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px; "><input id="price_'+i+'_'+counter1 +'_'+dt+'" name="price[]" class="price_class" onblur="findPriceTotal()"  onchange="newTotal_price('+i+','+counter1+','+dt+','+x+','+y+','+dt+')" placeholder="Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="price_class"></div>'
			+'<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px; "><input id="supplier_price_'+i+'_'+counter1 +'_'+dt+'" name="supplier_price[]" class="supplier_price_class"  onchange="newTotalsupplier('+i+','+counter1+','+dt+','+x+','+y+','+dt+')" placeholder="Supplier Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"></div>'
			+'<div class="check_row_box" style="float: left;width: 7%;	padding-right: 14px;"><input  id="total_price_'+i+'_' + counter1 +'_'+dt+'" readonly name="total_price[]" onblur="findTotal()" class="total_price_class" placeholder="Total Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"></div>'

			+'<div class="check_row_box" style="float: left;width: 18%;	padding-right: 10px; "><textarea id="itinerary_package_additional_instructions_'+i+'_' + counter1 +'_'+dt+'" name="itinerary_package_additional_instructions[]"   placeholder="Additional Instructions here..."  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="itinerary_package_additional_instructions_class"></textarea></div>'

			+'<div class="check_row_box" style="float: left;width: 1%;	padding-right: 9px;"><input type="checkbox" id="check_price'+i+'_'+counter1+'_'+dt+'" name="check_price1" onclick="check_uncheck_price(\'' +i+'_'+counter1+'_'+dt+ '\');"  style="height: 15px;width: 15px;margin-top: 6px;margin-left:8px;"><input type="hidden" name="check_price[]" id="check_price_hidden_'+i+'_'+counter1+'_'+dt+'" value="0"></div>'
			
			+'<div class="check_row_box" style="float: left;text-align: center;margin-left:9px;margin-top:5px;">'
			+'<img class="remove_location_button"  title="Remove" onclick="deleteRow('+i+','+counter1 +','+x+','+y+','+dt+','+after_div_new+')" style="cursor:pointer;" id="remove_btn_'+i+'_'+ counter1 + '" src="../images/icons/no.png">'
			+'</div><input type="hidden" id="on_date_' + i + '" name="on_date[]" value="'+on_date_concate+'">');
		   
		     // $("#InputBoxDiv_"+x+'_'+y+'_'+dt).before(newTextBoxDiv);

		 }
		       <?php 
					if($source=='girlzweekend'){?>
					
						fill_product(i,counter1);
					<? }?>
		counter1++;
		counter2++;
	}
	// end child append code
	//for remove option
	function deleteRow(rmv,row_no,first_id,second_id,third_id,after_div) 
	{
		// alert('test');
		// alert(after_div);
		var x=rmv+'_'+row_no;
		// alert("#row_box_" + x);
		$("#"+after_div).remove();
        subtotal_datevise(first_id,second_id,third_id);
        grandtotal_datewise();
        grandtotal_pricewise();
        grandtotal_supplierwise();
	    subtotal_datevise_supplier(first_id,second_id,third_id);
	    
		var do_change=0;
      // $("#TextBoxDiv_"+first_id+'_'+second_id+'_'+third_id+" tr td div").each(function () { 
      	$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".row_box").each(function() {
      	// alert($(this).attr( "class" ));     
		if($(this).hasClass("row_box"))
        {	
            do_change++;
        }
    	else{
    		do_change=0;
    		
    	}
    
    });
    // alert(do_change);
    	if(do_change==0)
    	{
    		document.getElementById("add_prdct_div_"+first_id+'_'+second_id+'_'+third_id).style.display = "block";
    	}     

	}
	
	function deleteStoredRow(rmv,row_no,j,dt,first_id,second_id,third_id)
	{
		
    var x=rmv+'_'+row_no+'_'+dt;
	var j = j;
	$("#row_box_" + x).remove();
        subtotal_datevise(first_id,second_id,third_id);
        grandtotal_datewise();
        grandtotal_pricewise();
       grandtotal_supplierwise();
	subtotal_datevise_supplier(first_id,second_id,third_id);

	var do_change=0;
	$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".row_box").each(function() {
      // $("#TextBoxDiv_"+first_id+'_'+second_id+'_'+third_id+" tr td div").each(function () { 

      	// alert($(this).attr( "class" ));     
		if($(this).hasClass("row_box"))
        {	
        	
        	do_change++;
        	
         }
    	else{
    		do_change=0;

    	    }
    	
   		 });
   		 // alert(do_change);
    	if(do_change==0)
    	{
    		document.getElementById("add_prdct_div_"+first_id+'_'+second_id+'_'+third_id).style.display = "block";
    	}  
	}
</script>     
<script type="text/javascript">
// $("#add_prdct_div_"+first_id+'_'+second_id+'_'+third_id+).click(function(){
// 	alert('teswt');
// });
function hide_div(first_id,second_id,third_id)
{
	
	document.getElementById("add_prdct_div_"+first_id+'_'+second_id+'_'+third_id).style.display = "none";
}
</script>
<style>
	input, textarea, select {
		font-family: inherit;
		font-size: inherit;
		font-weight: inherit;/
		line-height: 25px;
		padding-left: 10px;
	}
	table {
		border-collapse: inherit;
		border-spacing: 10px;
	}
	.btn_create {
		padding: 10px;
		text-transform: capitalize;
		font-size: 20px;
		color: #1697C9;
		font-weight: bold;
		cursor: pointer;
	}
</style>
<?php 
if(isset($_GET['id'])){
// Setup Data
$id = $_GET['id'];
$q = "SELECT * FROM itinerary WHERE id = '$id'";
$query = $database->query($q);
$info = mysql_fetch_array($query);
?>
<!-- modules/itinerary/update_itinerary.php -->
<form action="modules/itinerary/update_itinerary.php" method="post" enctype="multipart/form-data">
	<table cellspacing="10" >
		<?php $page['title'] = 'Update an Itinerary';?>

		
		<tr >
			<td>Dates:</td>
			<td><input id="id" name="id" hidden value="<?php echo $id ;?>">
				<input id="from_date" required="true" type="date" style="padding-left: 10px;" name="from_date" onChange="days_between()" placeholder="from yyyy-mm-dd" value="<?php echo $info['from_date']; ?>" readonly/> 
				&nbsp;to&nbsp;
				<input id="to_date" type="date" style="padding-left: 0px;" name="to_date"  onChange="days_between()" placeholder="to yyyy-mm-dd" value="<?php echo $info['to_date']; ?>" readonly/>
			</td>
		</tr>
		<tr>
		<?php if($source=='boyzweekend'){?>

			<td>Stags Name:</td>

		<?}else{?>

			<td>Hens Name:</td>

		<?} ?>
			<td>
				<input id="stags_name" required="true" type="text" name="stags_name" size="47" placeholder="<?php if($source=='boyzweekend'){ echo 'Stags Name';}else{ echo 'Hens Name';} ?>" value="<?php echo $info['stags_name']; ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Clients Name:</td>
			<td>
				<input id="bestmans_name" required="true" type="text" name="bestmans_name" size="47" placeholder="Clients Name" value="<?php echo $info['bestmans_name']; ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Client Ph #:</td>
			<td>
				<input id="clients_phone_number"  type="text" name="clients_phone_number" size="47" placeholder="Client Phone Number" value="<?php echo $info['clients_phone_number']; ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Venue:</td>
			<td>
				<input id="venue" required="true" type="text" name="venue" size="47" placeholder="In and around Taupo" value="<?php echo $info['venue']; ?>"/> 
			</td>
		</tr>
		<tr>
			<td>Accommodation:</td>
			<td>
				<input id="accommodation" required="true" type="text" name="accommodation" size="47" placeholder="Backpacker" value="<?php echo $info['accommodation']; ?>"/> 
			</td>
		</tr>
		<tr id="for_no_of_nights" >
			<td>Number of Nights:</td>
			<td>
				<select id="number_of_nights" name="number_of_nights">
					<option value="">Select Number of Nights</option>
					<option value="1"<?php if($info['number_of_nights']==1){ echo 'selected="selected"';} ?>>1</option>
					<option value="2"<?php if($info['number_of_nights']==2){ echo 'selected="selected"';} ?>>2</option>
					<option value="3"<?php if($info['number_of_nights']==3){ echo 'selected="selected"';} ?>>3</option>
					<option value="4"<?php if($info['number_of_nights']==4){ echo 'selected="selected"';} ?>>4</option>
					<option value="5"<?php if($info['number_of_nights']==5){ echo 'selected="selected"';} ?>>5</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>Transport:</td>
			<td>
				<input id="transport" required="true" size="47" placeholder="Transport" type="text" name="transport" value="<?php echo $info['transport']; ?>" /> 
			</td>
		</tr>
		<tr>
			<td>Number:</td>
			<td>
				<input id="number_of_persons" placeholder="Number of Persons"  type="text" name="number_of_persons" size="47" onkeyup="checkNAN()" value="<?php if($info['number_of_persons']!='0'){ echo $info['number_of_persons'];} ?>"/> <p style="color:red" id="Error_num" ></p>
				
			</td> 
		</tr> 
		<tr>
			<td colspan="2">
				<div id='TextBoxesGroup'>
	<?php
		$diff=abs(strtotime($info['to_date']) - strtotime($info['from_date']));
		
		$years = floor($diff / (365*60*60*24));
		$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
		 $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
	if($days==0){
		$days=1;
	}
	$dt=1;
	for($dx=0;$dx<$days;$dx++){
	$next_date1 = date('l d M', strtotime($info['from_date'].' +'.$dx.' day'));
	 $next_date = date('Y-m-d', strtotime($info['from_date'].' +'.$dx.' day'));
	 $day_detail1 = "SELECT Distinct(date) FROM itinerary_package WHERE itinerary_id = '$id' and date = '$next_date' order by date asc";
	$day_detail2 = $database->query($day_detail1);
	// $after_div="'row_box_0_2_3'";
	$after_div="'row_box_0_".$dt."_".$dt."'";

	if(mysql_num_rows($day_detail2)==0){ 
	$row_box_count = mysql_num_rows($day_detail2);

 $name_row_box_count = date_format(date_create($next_date),"d").'_'.sprintf("%02d", date_format(date_create($next_date),"m")).'_'.date_format(date_create($next_date),"Y");
		
		echo '<input type="hidden" value="'.($row_box_count+1).'" id="row_box_count_'.$name_row_box_count.'">';
		?>
		<div style="margin-top: 15px;" id="DateShowDiv1"><?php echo $next_date1;?></div>
		<table  id="TextBoxDiv_0_<?php echo $dt;?>_<?php echo $dt;?>" class="TextBoxDiv_class" style="padding:15px;width:130%;border: 1px solid #ddd;margin-bottom: 15px;">
			<tr><td>
				<div style="float:left;margin-top: -20px; "><span style="border: 1px solid darkgray;padding: 3px;background-color: #E7E7E7;">Numbers</span></div>

			<?php
				$add_product_btn_count=0;
    			if($add_product_btn_count==$row_box_count)
    			{ 
    			?>
    			<div onclick="hide_div(0,<?php echo $dt; ?>,<?php echo $dt; ?>);" style="float:right;margin-top: -15px; display: block;" id="add_prdct_div_0_<?php echo $dt; ?>_<?php echo $dt; ?>" class="check_row_box">
		<a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child(0,<?php echo date_format(date_create($next_date),"d"); ?>,<?php echo  date_format(date_create($next_date),"m"); ?>,<?php echo date_format(date_create($next_date),"Y"); ?>,<?php echo $dt;?>,<?php echo $dt;?>,<?php echo $after_div;?>);" > + Add Product </a>	
		</div>
		<?php }?>

		</td></tr>

<tr id="InputBoxDiv_<?php echo '0';?>_<?php echo $dt;?>_<?php echo $dt;?>">
<td><div class="check_row_box" style='margin-left:529px;'><strong>Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  id="price_total" class="price_total" name="price_total" style="width:79px;padding-left: 1px;padding:1px;" disabled>&nbsp;<input type="text"  id="supplier_price_total" class="supplier_price_total" name="supplier_price_total" style="width:79px;padding-left: 1px;padding:1px;" disabled>&nbsp;<input type="text" id="sum_total" class="sum_total" name="total" style="width:79px;padding-left: 1px;padding:1px;margin-left:-2px;"  disabled></div></td>
	</tr>
		</table>
	<?php 
	
	}
	else{
		
	
	
	$j=2;
	$i=2;
	while($day_date = mysql_fetch_array($day_detail2))
	{ ?>
		<div style="margin-top: 15px;" id="DateShowDiv1">
		<?php $date_1=date_create($day_date['date']);
					$today = date_format($date_1,"l d M");
					?>
			<?php
				$day_detail = "SELECT * FROM itinerary_package WHERE itinerary_id = '$id' and date = '$day_date[date]'; ";
				$day_detail_1 = $database->query($day_detail);
		 
				 
				 
					echo $today;
				
				
				$for_sub_total_first_id = $j;
				$for_sub_total_second_id = $i;
				$for_sub_total_third_id = $dt;

				
				?>
			
		</div>

		<table  id="TextBoxDiv_<?php echo $j;?>_<?php echo $i;?>_<?php echo $dt;?>" class="TextBoxDiv_class" style="padding:15px;width:130%;border: 1px solid #ddd;margin-bottom: 15px;">
			<tr><td>
				<div style="float:left;margin-top: -20px; " class="check_row_box"><span style="border: 1px solid darkgray;padding: 3px;background-color: #E7E7E7;">Numbers</span></div>

		<?php
		
		$row_box_count = mysql_num_rows($day_detail_1);
 $name_row_box_count = date_format(date_create($day_date['date']),"d").'_'.sprintf("%02d", date_format(date_create($day_date['date']),"m")).'_'.date_format(date_create($day_date['date']),"Y");
		
		echo '<input type="hidden" value="'.($row_box_count+1).'" id="row_box_count_'.$name_row_box_count.'">';
		$add_product_btn_count=0;
		while($day_detail_info = mysql_fetch_array($day_detail_1))
		{
			$x = strtotime($day_detail_info['time_from']);
			$y = strtotime($day_detail_info['time_to']);
			$timecount =strtotime('17:17:17');
		if( $x == $timecount  &&  $y == $timecount  ){
			
			$time_from ='00:00:00';
			$time_to ='00:00:00';
			
		}else{
			 $time_from = date("g:i A", strtotime($day_detail_info['time_from']));
		 	$time_to = date("g:i A", strtotime($day_detail_info['time_to']));
		}
		if($x == $timecount) {
		$time_from ='00:00:00';
		}else {
		 $time_from = date("g:i A", strtotime($day_detail_info['time_from']));
		}
		
		if($y == $timecount) {
		$time_to ='00:00:00';
		}else {
		$time_to = date("g:i A", strtotime($day_detail_info['time_to']));
		}

		$after_div2="'row_box_0_".$i."_".$dt."'";
			?>
				<?php
				$add_product_btn_count++;
    			if($add_product_btn_count==$row_box_count)
    			{ 
    			?>
    			<div onclick="hide_div(<?php echo $for_sub_total_first_id; ?>,<?php echo $for_sub_total_second_id; ?>,<?php echo $for_sub_total_third_id; ?>);" style="float:right;margin-top: -15px; display: none;" id="add_prdct_div_<?php echo $for_sub_total_first_id; ?>_<?php echo $for_sub_total_second_id; ?>_<?php echo $for_sub_total_third_id; ?>" class="check_row_box">
		<a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child(<?php echo $j;?>,<?php echo date_format(date_create($day_date['date']),"d"); ?>,<?php echo sprintf("%02d", date_format(date_create($day_date['date']),"m")); ?>,<?php echo date_format(date_create($day_date['date']),"Y"); ?>,2,<?php echo $dt;?>,<?php echo $after_div2;?>);" > + Add Product </a>	
		</div>
		<?php }?>
    		<div class="row_box" id="row_box_0_<?php echo $i; ?>_<?php echo $dt;?>" style="margin-bottom: 10px;float: left;margin-top: 12px;">
    			<div class="check_row_box" style="float: left;width: 7%; "><input name="numbers[]" id="calculate_row_<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" style="padding:2px;border-radius: 0px;margin-top: 3px;width:75%;"  class="row_total" onkeyup="numbers_total(<?php echo $j; ?>,<?php echo $i; ?>,<?php echo $dt; ?>,<?php echo $for_sub_total_first_id; ?>,<?php echo $for_sub_total_second_id; ?>,<?php echo $for_sub_total_third_id; ?>)" value="<?php if($day_detail_info['numbers'] !='0'){echo $day_detail_info['numbers'];}?>"></div>
    			<?php
    			
    			?>
    			<div style="float:right;margin-top: -15px;" class="check_row_box">
		<a style="" id="add_more_product_1" class="add_more_product_1" href="javascript:void(0);" onclick="newProduct_child(<?php echo $j;?>,<?php echo date_format(date_create($day_date['date']),"d"); ?>,<?php echo sprintf("%02d", date_format(date_create($day_date['date']),"m")); ?>,<?php echo date_format(date_create($day_date['date']),"Y"); ?>,2,<?php echo $dt;?>,<?php echo $after_div2;?>);" > + Add Product </a>	
		</div>
		<?php
		
		?>
    			<div class="check_row_box" style="float: left;width: 30%; ">
    				<div class="select select-block check_row_box">
				
					<?php $product_data = "SELECT * FROM products WHERE source='$source' ORDER BY title ASC "; 
					$product_result = mysql_query($product_data);?>
					<select id="product_<?php echo $j; ?>_<?php echo $i; ?>" class="product_list" name="product[]" style="width: 97%;padding:2px;border-radius: 0px;margin-top: 3px;" onChange="productPrice(<?php echo $j; ?>,<?php echo $i; ?>,<?php echo $dt; ?>,<?php echo $for_sub_total_first_id; ?>,<?php echo $for_sub_total_second_id; ?>,<?php echo $for_sub_total_third_id; ?>)">
					<?php echo $product_data_preloaded = "SELECT * FROM products WHERE id = '$day_detail_info[product_id]' AND source='$source' "; 
					$product_result_preloaded = mysql_query($product_data_preloaded);
					$product_preloaded_info = mysql_fetch_array($product_result_preloaded);
					?>
					<option value= "<?php echo $product_preloaded_info['id']; ?>"><?php  echo $product_preloaded_info['title']; ?>
					</option>
					<option value=""></option>
					<?php while($product_info = mysql_fetch_array($product_result)){ ?>
					<option value= "<?php echo $product_info[id];?>">
					<?php echo $product_info[title]; ?>
					</option>
					<?php } ?> 
					</select>
					</div>
				</div>

					<div class="select select-block check_row_box" style="float: left;width: 7%; 	padding-right: 10px;">
						<select id="from_time_<?php echo $j; ?>_<?php echo $i; ?>" class="from_time" name="from_time[]"style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >
					<option value="<?php echo $day_detail_info['time_from'];?>">
						<?php 
						 echo  $time_from;
						 ?>
					</option>
					<option value="17:17:17"></option>
					<option value="24:00:00">12:00 AM</option>
					<option value="24:15:00">12:15 AM</option>
					<option value="24:30:00">12:30 AM</option>
					<option value="24:45:00">12:45 AM</option>
					<option value="01:00:00">01:00 AM</option>
					<option value="01:15:00">01:15 AM</option>
					<option value="01:30:00">01:30 AM</option>
					<option value="01:45:00">01:45 AM</option>
					<option value="02:00:00">02:00 AM</option>
					<option value="02:15:00">02:15 AM</option>
					<option value="02:30:00">02:30 AM</option>
					<option value="02:45:00">02:45 AM</option>
					<option value="03:00:00">03:00 AM</option>
					<option value="03:15:00">03:15 AM</option>
					<option value="03:30:00">03:30 AM</option>
					<option value="03:45:00">03:45 AM</option>
					<option value="04:00:00">04:00 AM</option>
					<option value="04:15:00">04:15 AM</option>
					<option value="04:30:00">04:30 AM</option>
					<option value="04:45:00">04:45 AM</option>
					<option value="05:00:00">05:00 AM</option>
					<option value="05:15:00">05:15 AM</option>
					<option value="05:30:00">05:30 AM</option>
					<option value="05:45:00">05:45 AM</option>
					<option value="06:00:00">06:00 AM</option>
					<option value="06:15:00">06:15 AM</option>
					<option value="06:30:00">06:30 AM</option>
					<option value="06:45:00">06:45 AM</option>
					<option value="07:00:00">07:00 AM</option>
					<option value="07:15:00">07:15 AM</option>
					<option value="07:30:00">07:30 AM</option>
					<option value="07:45:00">07:45 AM</option>
					<option value="08:00:00">08:00 AM</option>
					<option value="08:15:00">08:15 AM</option>
					<option value="08:30:00">08:30 AM</option>
					<option value="08:45:00">08:45 AM</option>
					<option value="09:00:00">09:00 AM</option>
					<option value="09:15:00">09:15 AM</option>
					<option value="09:30:00">09:30 AM</option>
					<option value="09:45:00">09:45 AM</option>
					<option value="10:00:00">10:00 AM</option>
					<option value="10:15:00">10:15 AM</option>
					<option value="10:30:00">10:30 AM</option>
					<option value="10:45:00">10:45 AM</option>
					<option value="11:00:00">11:00 AM</option>
					<option value="11:15:00">11:15 AM</option>
					<option value="11:30:00">11:30 AM</option>
					<option value="11:45:00">11:45 AM</option>
					<option value="12:00:00">12:00 PM</option>
					<option value="12:15:00">12:15 PM</option>
					<option value="12:30:00">12:30 PM</option>
					<option value="12:45:00">12:45 PM</option>
					<option value="13:00:00">01:00 PM</option>
					<option value="13:15:00">01:15 PM</option>
					<option value="13:30:00">01:30 PM</option>
					<option value="13:45:00">01:45 PM</option>
					<option value="14:00:00">02:00 PM</option>
					<option value="14:15:00">02:15 PM</option>
					<option value="14:30:00">02:30 PM</option>
					<option value="14:45:00">02:45 PM</option>
					<option value="15:00:00">03:00 PM</option>
					<option value="15:15:00">03:15 PM</option>
					<option value="15:30:00">03:30 PM</option>
					<option value="15:45:00">03:45 PM</option>
					<option value="16:00:00">04:00 PM</option>
					<option value="16:15:00">04:15 PM</option>
					<option value="16:30:00">04:30 PM</option>
					<option value="16:45:00">04:45 PM</option>
					<option value="17:00:00">05:00 PM</option>
					<option value="17:15:00">05:15 PM</option>
					<option value="17:30:00">05:30 PM</option>
					<option value="17:45:00">05:45 PM</option>
					<option value="18:00:00">06:00 PM</option>
					<option value="18:15:00">06:15 PM</option>
					<option value="18:30:00">06:30 PM</option>
					<option value="18:45:00">06:45 PM</option>
					<option value="19:00:00">07:00 PM</option>
					<option value="19:15:00">07:15 PM</option>
					<option value="19:30:00">07:30 PM</option>
					<option value="19:45:00">07:45 PM</option>
					<option value="20:00:00">08:00 PM</option>
					<option value="20:15:00">08:15 PM</option>
					<option value="20:30:00">08:30 PM</option>
					<option value="20:45:00">08:45 PM</option>
					<option value="21:00:00">09:00 PM</option>
					<option value="21:15:00">09:15 PM</option>
					<option value="21:30:00">09:30 PM</option>
					<option value="21:45:00">09:45 PM</option>
					<option value="22:00:00">10:00 PM</option>
					<option value="22:15:00">10:15 PM</option>
					<option value="22:30:00">10:30 PM</option>
					<option value="22:45:00">10:45 PM</option>
					<option value="23:00:00">11:00 PM</option>
					<option value="23:15:00">11:15 PM</option>
					<option value="23:30:00">11:30 PM</option>
					<option value="23:45:00">11:45 PM</option>
					</select></div>
					<div class="select select-block check_row_box" style="float: left;width: 7%; 	padding-right: 10px;">
						<select id="to_time_<?php echo $j; ?>_<?php echo $i; ?>" class="to_time" name="to_time[]" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" >'
					<option value="<?php echo $day_detail_info['time_to'];?>">
						<?php echo $time_to ;?>
					</option>
					<option value="17:17:17"></option>
					<option value="24:00:00">12:00 AM</option>
					<option value="24:15:00">12:15 AM</option>
					<option value="24:30:00">12:30 AM</option>
					<option value="24:45:00">12:45 AM</option>
					<option value="01:00:00">01:00 AM</option>
					<option value="01:15:00">01:15 AM</option>
					<option value="01:30:00">01:30 AM</option>
					<option value="01:45:00">01:45 AM</option>
					<option value="02:00:00">02:00 AM</option>
					<option value="02:15:00">02:15 AM</option>
					<option value="02:30:00">02:30 AM</option>
					<option value="02:45:00">02:45 AM</option>
					<option value="03:00:00">03:00 AM</option>
					<option value="03:15:00">03:15 AM</option>
					<option value="03:30:00">03:30 AM</option>
					<option value="03:45:00">03:45 AM</option>
					<option value="04:00:00">04:00 AM</option>
					<option value="04:15:00">04:15 AM</option>
					<option value="04:30:00">04:30 AM</option>
					<option value="04:45:00">04:45 AM</option>
					<option value="05:00:00">05:00 AM</option>
					<option value="05:15:00">05:15 AM</option>
					<option value="05:30:00">05:30 AM</option>
					<option value="05:45:00">05:45 AM</option>
					<option value="06:00:00">06:00 AM</option>
					<option value="06:15:00">06:15 AM</option>
					<option value="06:30:00">06:30 AM</option>
					<option value="06:45:00">06:45 AM</option>
					<option value="07:00:00">07:00 AM</option>
					<option value="07:15:00">07:15 AM</option>
					<option value="07:30:00">07:30 AM</option>
					<option value="07:45:00">07:45 AM</option>
					<option value="08:00:00">08:00 AM</option>
					<option value="08:15:00">08:15 AM</option>
					<option value="08:30:00">08:30 AM</option>
					<option value="08:45:00">08:45 AM</option>
					<option value="09:00:00">09:00 AM</option>
					<option value="09:15:00">09:15 AM</option>
					<option value="09:30:00">09:30 AM</option>
					<option value="09:45:00">09:45 AM</option>
					<option value="10:00:00">10:00 AM</option>
					<option value="10:15:00">10:15 AM</option>
					<option value="10:30:00">10:30 AM</option>
					<option value="10:45:00">10:45 AM</option>
					<option value="11:00:00">11:00 AM</option>
					<option value="11:15:00">11:15 AM</option>
					<option value="11:30:00">11:30 AM</option>
					<option value="11:45:00">11:45 AM</option>
					<option value="12:00:00">12:00 PM</option>
					<option value="12:15:00">12:15 PM</option>
					<option value="12:30:00">12:30 PM</option>
					<option value="12:45:00">12:45 PM</option>
					<option value="13:00:00">01:00 PM</option>
					<option value="13:15:00">01:15 PM</option>
					<option value="13:30:00">01:30 PM</option>
					<option value="13:45:00">01:45 PM</option>
					<option value="14:00:00">02:00 PM</option>
					<option value="14:15:00">02:15 PM</option>
					<option value="14:30:00">02:30 PM</option>
					<option value="14:45:00">02:45 PM</option>
					<option value="15:00:00">03:00 PM</option>
					<option value="15:15:00">03:15 PM</option>
					<option value="15:30:00">03:30 PM</option>
					<option value="15:45:00">03:45 PM</option>
					<option value="16:00:00">04:00 PM</option>
					<option value="16:15:00">04:15 PM</option>
					<option value="16:30:00">04:30 PM</option>
					<option value="16:45:00">04:45 PM</option>
					<option value="17:00:00">05:00 PM</option>
					<option value="17:15:00">05:15 PM</option>
					<option value="17:30:00">05:30 PM</option>
					<option value="17:45:00">05:45 PM</option>
					<option value="18:00:00">06:00 PM</option>
					<option value="18:15:00">06:15 PM</option>
					<option value="18:30:00">06:30 PM</option>
					<option value="18:45:00">06:45 PM</option>
					<option value="19:00:00">07:00 PM</option>
					<option value="19:15:00">07:15 PM</option>
					<option value="19:30:00">07:30 PM</option>
					<option value="19:45:00">07:45 PM</option>
					<option value="20:00:00">08:00 PM</option>
					<option value="20:15:00">08:15 PM</option>
					<option value="20:30:00">08:30 PM</option>
					<option value="20:45:00">08:45 PM</option>
					<option value="21:00:00">09:00 PM</option>
					<option value="21:15:00">09:15 PM</option>
					<option value="21:30:00">09:30 PM</option>
					<option value="21:45:00">09:45 PM</option>
					<option value="22:00:00">10:00 PM</option>
					<option value="22:15:00">10:15 PM</option>
					<option value="22:30:00">10:30 PM</option>
					<option value="22:45:00">10:45 PM</option>
					<option value="23:00:00">11:00 PM</option>
					<option value="23:15:00">11:15 PM</option>
					<option value="23:30:00">11:30 PM</option>
					<option value="23:45:00">11:45 PM</option>
					</select></div>
				
					 
					<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px; ">
						<input id="price_<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" name="price[]" onblur="findPriceTotal()"   onchange="newTotal_price(<?php echo $j; ?>,<?php echo $i; ?>,<?php echo $dt; ?>,<?php echo $for_sub_total_first_id; ?>,<?php echo $for_sub_total_second_id; ?>,<?php echo $for_sub_total_third_id; ?>)" placeholder="Price" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="price_class" value="<?php echo $day_detail_info['price'];?>"/></div>
						<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px; ">
						<input id="supplier_price_<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" name="supplier_price[]"  onchange="newTotalsupplier(<?php echo $j; ?>,<?php echo $i; ?>,<?php echo $dt; ?>,<?php echo $for_sub_total_first_id; ?>,<?php echo $for_sub_total_second_id; ?>,<?php echo $for_sub_total_third_id; ?>)"  placeholder="Supplier Price" style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" class="supplier_price_class" value="<?php echo $day_detail_info['supplier_price'];?>"/></div>
					<div class="check_row_box" style="float: left;width: 7%;	padding-right: 10px;">
						<input  id="total_price_<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" readonly name="total_price[]" onblur="findTotal()" class="total_price_class" placeholder="Total Price"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;" value="<?php echo $day_detail_info['total_price'];?>">
						
					</div>

					<div class="check_row_box" style="float: left;width: 18%;	padding-right: 10px; ">
						<textarea id="itinerary_package_additional_instructions_<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" name="itinerary_package_additional_instructions[]"   placeholder="Additional Instructions here..." class="itinerary_package_additional_instructions_class"  style="padding:2px;border-radius: 0px;margin-top: 3px;width:100%;"><?php echo $day_detail_info['itinerary_package_additional_instructions']; ?></textarea></div>

	
	<div class="check_row_box" style="float: left;width: 2%;	padding-right: 10px;"><input type="checkbox" id="check_price<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" name="check_price1"  <?php if($day_detail_info['check_price']==1){ echo "checked='checked'";} ?> onclick="check_uncheck_price('<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>');"  style="height: 15px;width: 15px;margin-top: 6px;margin-left:10px;"><input type="hidden" name="check_price[]" id="check_price_hidden_<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" value="<?php echo $day_detail_info['check_price']; ?>" ></div>


	 	<div style="float: left;text-align:center;margin-left:2px;margin-top:5px;" class="check_row_box">
			<img class="remove_location_button"  title="Remove" onclick="deleteStoredRow(0,<?php echo $i; ?>,<?php echo $j; ?>,<?php echo $dt; ?>,<?php echo $for_sub_total_first_id; ?>,<?php echo $for_sub_total_second_id; ?>,<?php echo $for_sub_total_third_id; ?>)" style="cursor:pointer;" id="remove_btn_<?php echo $j; ?>_<?php echo $i; ?>" src="../images/icons/no.png" />
			</div><input type="hidden" id="on_date<?php echo $i; ?>" name="on_date[]" value="<?php echo $day_date['date']; ?>">
			</div>
	
						<input type="hidden" id="itinerary_package_id<?php echo $j; ?>_<?php echo $i; ?>_<?php echo $dt; ?>" name="itinerary_package_id[]" value="<?php echo $day_detail_info['id']; ?>">
			
		<?php 
	    
		$i++;
	} 
    $k=2;
	?></td></tr>
      
	<tr id="InputBoxDiv_<?php echo $j;?>_<?php echo $k;?>_<?php echo $dt;?>">
<td><div class="check_row_box" style='margin-left:529px;'><strong>Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  id="price_total" class="price_total" name="price_total" style="width:79px;padding-left: 1px;padding:1px;" disabled>&nbsp;<input type="text"  id="supplier_price_total" class="supplier_price_total" name="supplier_price_total" style="width:79px;padding-left: 1px;padding:1px;" disabled>&nbsp;<input type="text" id="sum_total" class="sum_total" name="total" style="width:79px;padding-left: 1px;padding:1px;margin-left:-2px;"  disabled></div></td>
	</tr>
</table>

  
   <script type="text/javascript">
$(document).ready(function(){
var  first_id = "<?php echo $j;  ?>";
var  second_id = "<?php echo $k ?>";
var  third_id = "<?php echo $dt ?>";


	var total_for_price=0;
		$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".total_price_class").each(function() {
 		 var sum_for_price=$( this ).val();
  		 total_for_price=parseFloat(total_for_price)+parseFloat(sum_for_price);

		});
$( "#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".sum_total").val(total_for_price);


	var total_for_rate=0;
		$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".price_class").each(function() {
  		var sum_for_rate=$( this ).val();
  		total_for_rate=parseFloat(total_for_rate)+parseFloat(sum_for_rate);


		});
$( "#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".price_total").val(total_for_rate);

	
	var total_for_supplier=0;
		$( "#TextBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".supplier_price_class").each(function() {
  		var sum_for_supplier=$( this ).val();
  		total_for_supplier=parseFloat(total_for_supplier)+parseFloat(sum_for_supplier);


		});
$( "#InputBoxDiv_"+first_id+"_"+second_id+"_"+third_id).find(".supplier_price_total").val(total_for_supplier);



   
});



</script>

	<?php  $k++;	$j++;
	} 
	}
	$dt++;
	} ?>  
   </div>	</td>
		</tr>
		<tr><td colspan="2"></td></tr>
		<tr align="center">
			<td colspan="2">
				<input type="hidden"  name="source" value="<?php echo $source ;?>"/>
				<input type="submit" class="btn_create" name="update" value="Update"/>
				
			</td>
		</tr>
	</table>
</form>
<?php 
}else{
	echo "itinerary id not set";
}
include('template/generic/page-footer.php'); ?>
<?php include('template/generic/footer.php'); ?>	

<script type="text/javascript">
//commented
	// $(document).ready(function(){

	// $('#number_of_persons').keyup(function(){$('.row_total').val($(this).val());});

	// });
//commented
$(document).ready(function(){

  $("<div id='grt' style='margin-left:514px;width:72%;'><td><strong>Grand Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><input type='text' id='grandpricetotal' class='grandpricetotal' name='grandpricetotal' style='width:79px;padding-left:1px;padding:1px;' disabled></td>&nbsp;<td><input type='text' id='grandsuppliertotal' class='grandsuppliertotal' name='grandsuppliertotal' style='width:79px;padding-left:1px;padding:1px;' disabled></td>&nbsp;<td><input type='text' id='grandtotal' class='grandtotal' name='grandtotal' style='width:79px;padding-left:1px;padding:1px;margin-left:-2px;' disabled></td></div>").insertAfter($(".TextBoxDiv_class:last"));

});
$(document).ready(function(){
		var total_for_price=0;
		$(".total_price_class").each(function() {
  			var sum_for_price=$( this ).val();
  
  			total_for_price=parseFloat(total_for_price)+parseFloat(sum_for_price);

			});
		$( ".grandtotal").val(total_for_price);

		var total_for_rate=0;
		$(".price_class").each(function() {
  			var sum_for_rate=$( this ).val();
  
  			total_for_rate=parseFloat(total_for_rate)+parseFloat(sum_for_rate);

			});
		$( ".grandpricetotal").val(total_for_rate);

		var total_for_supplier=0;
		$(".supplier_price_class").each(function() {
  			var sum_for_supplier=$( this ).val();
  
  			total_for_supplier=parseFloat(total_for_supplier)+parseFloat(sum_for_supplier);

			});
		$( ".grandsuppliertotal").val(total_for_supplier);
   
});
</script>

<?php
$from_date_itinerary=$info['from_date'];
$to_date_itinerary=$info['to_date'];
$check_out_content=$info['check_out_content'];
if($from_date_itinerary<$to_date_itinerary)
{

 	$date_new=date_create($to_date_itinerary);
	$today_new = date_format($date_new,"l d M");

?>
<script type="text/javascript">
$(document).ready(function(){

	$("<div id='DateShow' style='margin-top: 15px;'><?php echo $today_new; ?></div><div style='width:130%;border: 1px solid #ddd;margin-bottom: 15px;'><div style='border: 1px solid #ddd;'><table style='width: 100%;'><tr><td style='width: 50%;border-right: 1px #cac6c6 solid;height: 20px;'>10 am</td><td style='text-align: center;'>Check Out - Free Day</td></tr><tr><td colspan='2' style='width: 50%;height: 20px;'><textarea  name='check_out_content' id='additional_content' placeholder='Additional Content Here.....'  style='width: 99%;height: 65px;' ><?php echo $check_out_content; ?></textarea></td></tr></table></div></div>").insertBefore($("#grt"));
});
</script>

<? } ?>


