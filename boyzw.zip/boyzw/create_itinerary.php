<?php
ini_set('session.gc_maxlifetime', 10800);
require_once("../../../include/session.php");
require_once("../../../include/class.mailer.php");
require_once("../../../include/class.utility.php");
require_once("../../../include/class.validator.php");
// Admin Module Test

 // print_r($_FILES);die();

if(isset($_POST['create']))
{	

	$source ='';
	if(isset($_POST['source']))
	{ 
		$source = $_POST['source'];
	}
	$source_url_param = "&source=$source";
	$stags_name = $_POST['stags_name'];
	$bestmans_name = $_POST['bestmans_name'];
	$clients_phone_number = $_POST['clients_phone_number'];
	$from_date = $_POST['from_date'];
	if($_POST['to_date']=='')
	{
		$to_date= $_POST['from_date'];
	}else
	{
		$to_date = $_POST['to_date'];
	}
	$venue = $_POST['venue'];
	$accommodation = $_POST['accommodation'];
	$number_of_nights = $_POST['number_of_nights'];
	$transport = $_POST['transport'];
	$number_of_persons = $_POST['number_of_persons'];
	$check_out_content = $_POST['check_out_content'];
	$created_on = date('Y-m-d H:i:s');

	$sql = "INSERT INTO `itinerary` (`stags_name`,`bestmans_name`,`clients_phone_number`, `from_date`, `to_date`, `venue`, `accommodation`,`number_of_nights`, `transport`, `number_of_persons`,`check_out_content`, `is_active`,`source`, `created_on`) VALUES ('$stags_name','$bestmans_name','$clients_phone_number','$from_date', '$to_date', '$venue', '$accommodation','$number_of_nights','$transport', '$number_of_persons', '$check_out_content','1', '$source', '$created_on')";
	 // echo $sql;echo "<br/>";
	 // die();
	 $result = mysql_query($sql);
	 $last_id = mysql_insert_id(); 
	//$last_id = 3;  
	if($last_id>0 &&isset($_POST['product']))
	{
		// 
		//print_r($_POST);

		$product 		= $_POST['product'];
		$from_time 		= $_POST['from_time'];
		$to_time  		= $_POST['to_time'];
		$numbers 		= $_POST['numbers'];
		$price  		= $_POST['price'];
		$supplier_price = $_POST['supplier_price'];
		$total_price  	= $_POST['total_price'];
		$itinerary_package_additional_instructions  	= $_POST['itinerary_package_additional_instructions'];
		$on_date		= $_POST['on_date'];
		$check_price	= $_POST['check_price'];
		// print_r($product );		
		 // print_r($from_time );print("<hr/>");
		 // print_r($to_time );		
		// print_r($price  );		
		// print_r($total_price);  	
		 // print_r($on_date);

		// echo "<pre>";echo "<br/>";

		// start product_image_upload code//
		// $product_image_name=$_FILES['image']['name'];
		// $product_image_size=$_FILES['image']['size'];
		// $product_image_tmp_name=$_FILES['image']['tmp_name'];
		// end product_image_upload code//
		$created_on1 	= date('Y-m-d H:i:s');
		$countdata=count($product);
		for($i = 0; $i<$countdata;$i++)
		{
			 $product_id1 						          = $product[$i];
			 $from_time1   	 							  = $from_time [$i];
			 $to_time1		 							  = $to_time[$i];
			 $numbers1		 							  = $numbers[$i];
			 $price1 		 							  = $price[$i];
			 $supplier_price1							  = $supplier_price[$i];
			 $total_price1 	 							  = $total_price[$i];
			 $itinerary_package_additional_instructions1  = $itinerary_package_additional_instructions[$i];
			 $on_date1		 							  = date('Y-m-d',strtotime($on_date[$i]));
			 $check_price1 =$check_price[$i];
			

			  // $product_image =$_FILES['image']['name'][$i];
			 // $image_name_for_product=rand().$product_image;
		 	
			// print_r($on_date1);
			// print("<hr/>inside loop"); print_r($from_time1);
			// print("<hr/>"); print_r($to_time1);
		$sql2="INSERT INTO `itinerary_package` (`itinerary_id`, `date`, `time_from`, `time_to`, `product_id`,`numbers`, `price`,`supplier_price`, `total_price`,`itinerary_package_additional_instructions`,`check_price`, `created_on`) VALUES ('$last_id', '$on_date1', '$from_time1', ' $to_time1', '$product_id1','$numbers1' ,'$price1','$supplier_price1', '$total_price1','$itinerary_package_additional_instructions1','$check_price1','$created_on1')";
			 $result2 = mysql_query($sql2);
			
			// echo $sql2;echo "<br/>";
		}
		
// die();
	}
		 $_SESSION['success_message'] = "Itinerary Created";
       header("Location: ".$session->referrer."?page=1&ipp=All&section=itinerary&act=view".$source_url_param);
}
else
{
	echo"Query Not Running";
}


					
?>
